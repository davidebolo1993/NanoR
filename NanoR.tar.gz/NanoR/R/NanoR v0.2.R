############################################ MinION DATA ANALYSIS  ############################################


 
############################################ NanoPrepareM ############################################


#' @title Prepares MinION data for your analyses with NanoR
#' @description NanoPrepareM generates an object of class "list" that contains informations required by other functions from NanoR when analyzing MinION data.
#' @param DataPass Path to MinION "Pass" .fast5 files folder (can find .fast5 files recursively)
#' @param DataFail Path to MinION "Fail" .fast5 files folder (can find .fast5 files recursively)
#' @param DataSkip Path to MinION "Skip" .fast5 files folder (can find .fast5 files recursively)
#' @param Label One label that identifies your MinION experiment
#' @details DataFail and DataSkip can be omitted as, altough MinION local basecaller (MinKNOW) generates "Pass", "Fail" and "Skip" .fast5 files folders, "Fail" and "Skip" .fast5 files are taken into account only for calculating their number and percentage.
#' @return Object of class "list" containing informations required by NanoTableM and NanoStatsM functions.
#' @examples
#' #do not run
#' PathPass<-"/Path/To/PassFast5"
#' Lab<-"Exp"
#' NanoMList<-NanoPrepareM(DataPass=PathPass, Label=Lab)


NanoPrepareM<-function(DataPass,DataFail=NA,DataSkip=NA,Label) { 
  
  PassFiles<-list.files(DataPass, full.names=TRUE, recursive = TRUE, pattern=".fast5")
  
  message("Found ", length(PassFiles), " .fast5 files specified as passed!")

  if (is.na(DataFail) == FALSE) {
    FailFilesLength<-length(list.files(DataFail, recursive = TRUE, pattern=".fast5"))
    message("Found ", FailFilesLength, " .fast5 files specified as failed!")
  }
  if (is.na(DataFail)) {
    FailFilesLength<-0
    message("No failed .fast5 files path specified.")
  }
  
  if (is.na(DataSkip) == FALSE) {
    SkipFilesLength<-length(list.files(DataSkip, recursive = TRUE, pattern=".fast5"))
    message("Found ", SkipFilesLength, " .fast5 files specified as skipped!")
  }
  if (is.na(DataSkip)) {
    SkipFilesLength<-0
    message("No skipped .fast5 files path specified.")
  }
  
  Label<-as.character(Label)
  
  List<-list(PassFiles,FailFilesLength,SkipFilesLength,Label)
  return(List)
}



############################################ NanoTableM ############################################


#' @title Generates an information table for your MinION .fast5 files
#' @description NanoTableM generates a table that contains useful informations for each read of the "Pass" .fast5 files folder given to NanoPrepareM function. As NanoTableM can take some time (it depends on the number of reads you obtain from your experiment), this function can be accelerated using multiple cores.
#' @param NanoPrepareMList The object of class "list" returned by NanoPrepareM function
#' @param DataOut Where the table will be saved. Don't use a directory that already contains another NanoTableM (or NanoTableG) result
#' @param Cores Number of cores to be used: 1 by default
#' @param GCC Logical. If TRUE (by default), NanoTableM computes GC content for each read
#' @return Table containing informations required by NanoStatsM and NanoCompare (and useful for users who want to analyze these data by theirselves!).
#' @examples
#' #do not run
#' NanoMTable<-NanoTableM(NanoPrepareMList=NanoMList, DataOut="/Path/To/DataOutExp",Cores=6,GCC=TRUE)


NanoTableM<-function(NanoPrepareMList,DataOut,Cores=1,GCC=TRUE) {
  
  library(parallel)
  library(rhdf5)
  library(seqinr)
  
  label<-as.character(NanoPrepareMList[[4]])
  Directory<-file.path(DataOut)
  dir.create(Directory, showWarnings = FALSE)
  setwd(Directory)
  TableInDirectory<-list.files(Directory,pattern="Information_Table.txt")
  if(length(TableInDirectory) != 0) {
    stop("Can't use a directory that already contains other NanoTableM/NanoTableG results")
  }
  
  ##### FUNCTIONS ######
  
  Read_DataSet<-function(File, PathGroup) { 
    h5errorHandling(type="suppress")
    Data1<-H5Dopen(File, PathGroup) 
    Data2<-H5Dread(Data1)
    H5Dclose(Data1)
    return(Data2) 
  }
  
  Read_Attributes<-function(PathGroup, Attribute) { 
    h5errorHandling(type="suppress")
    Data1<-H5Aopen(PathGroup, Attribute)
    Data2<-H5Aread(Data1)
    H5Aclose(Data1)
    return(Data2) 
  } 
  
  HDF5_File_Parsing_Table_With_GC<-function(i,File) {  ## work for R9.4 and R9.5
    
    h5errorHandling(type="suppress")
    Table<-c(Read_Id="Read_Id",Channel="Channel",Mux="Mux",Unix_Time="Unix_Time",Length="Length",Qscore="Qscore",GC_Content="GC_Content")
    
    File<-H5Fopen(File[i])
    
    Group1<-"/Analyses/Basecall_1D_000/BaseCalled_template/Fastq"
    Try<-try(Read_DataSet(File,Group1), silent=TRUE) #exclude non-basecalled .fast5 reads (will be counted as failed by NanoStats)
    if (inherits(Try,"try-error")) {
      return(Table)
    }
    
    else {
      
      Pre_Fastq<-Read_DataSet(File,Group1)
      Sequence_Fastq<-unlist(strsplit(Pre_Fastq,"\n"))[2]
      Fastq<-s2c(Sequence_Fastq)
      Table['GC_Content']<-GC(Fastq)
      
      Group2<-"/UniqueGlobalKey/channel_id"
      Chann_File<-H5Gopen(File,Group2)
      Table['Channel']<-Read_Attributes(Chann_File,"channel_number")
      H5Gclose(Chann_File)
      
      Group3<-"/Analyses/Basecall_1D_000/Summary/basecall_1d_template"
      Score_Length<-H5Gopen(File,Group3)
      Table['Qscore']<-Read_Attributes(Score_Length,"mean_qscore")
      Table['Length']<-Read_Attributes(Score_Length,"sequence_length")
      H5Gclose(Score_Length)
      
      #Group4<-"/Analyses/Basecall_1D_000/" ###No more used as sometimes it can have months in english word instead of numbers
      #Time<-H5Gopen(File,Group4)
      #if (H5Aexists(Time,"time_stamp")) {
        #Date<-Read_Attributes(Time,"time_stamp")
        #H5Gclose(Time)
        #Y_M_D<-substr(Date,1,10)
        #H_M_S<-substr(Date,12,19)
        #Time_Vector<-paste(c(Y_M_D,H_M_S), collapse=" ")
        #Table['Unix_Time']<-as.numeric(as.POSIXct(strptime(Time_Vector, "%Y-%m-%d %H:%M:%S")))
      #}
      #else {
        #H5Gclose(Time)
        #Table['Unix_Time']<-"Unix_Time"
      #}
      
      Group5<-"/Raw/Reads"
      Read_Mux<-H5Gopen(File,Group5)
      Template <- h5ls(Read_Mux,recursive=FALSE,datasetinfo=FALSE)
      H5Gclose(Read_Mux)
      Read_Path <- paste0("/Raw/Reads/",Template$name)
      
      Group6<- H5Gopen(File,Read_Path)
      
      Table['Mux']<-Read_Attributes(Group6,"start_mux")
      Table['Read_Id']<-Read_Attributes(Group6,"read_id")
      Start<-Read_Attributes(Group6,"start_time")
      AlternativeStart<-floor(Start/4000) ##actual sampling rate
      H5Gclose(Group6)
      
      ## try to compute a relative time using different parameters ##
      
     
      Group4.2<-"/UniqueGlobalKey/tracking_id"
      Time2<-H5Gopen(File,Group4.2)
      DateUnix2<-Read_Attributes(Time2,"exp_start_time")
      H5Gclose(Time2)
      if (length(unlist(strsplit(DateUnix2,"T")))==2) {### avoid problems with UNIX exp start times found on EGA samples
        Y_M_D<-substr(DateUnix2,1,10)
        H_M_S<-substr(DateUnix2,12,19)
        Time_Vector<-paste(c(Y_M_D,H_M_S), collapse=" ")
        Table['Unix_Time']<-as.numeric(as.POSIXct(strptime(Time_Vector, "%Y-%m-%d %H:%M:%S")))+AlternativeStart
      
      }
      else {
        Table['Unix_Time']<-(as.numeric(AlternativeStart)+as.numeric(DateUnix2))
      }
      
      
      H5Fclose(File)
      
      return(Table) 
    }
  }
  
  HDF5_File_Parsing_Table_Without_GC<-function(i,File) {  ## work for R9.4 and R9.5
    
    h5errorHandling(type="suppress")
    Table<-c(Read_Id="Read_Id",Channel="Channel",Mux="Mux",Unix_Time="Unix_Time",Length="Length",Qscore="Qscore",GC_Content="GC_Content")
    
    File<-H5Fopen(File[i])
    
    Group1<-"/Analyses/Basecall_1D_000/BaseCalled_template/Fastq"
    Try<-try(Read_DataSet(File,Group1), silent=TRUE) #exclude not-basecalled .fast5 files (will be counted as failed by NanoStats)
    if (inherits(Try,"try-error")) {
      return(Table)
    }
    
    else {
      
      
      Table['GC_Content']<-'GC_Content'
      
      Group2<-"/UniqueGlobalKey/channel_id"
      Chann_File<-H5Gopen(File,Group2)
      Table['Channel']<-Read_Attributes(Chann_File,"channel_number")
      H5Gclose(Chann_File)
      
      Group3<-"/Analyses/Basecall_1D_000/Summary/basecall_1d_template"
      Score_Length<-H5Gopen(File,Group3)
      Table['Qscore']<-Read_Attributes(Score_Length,"mean_qscore")
      Table['Length']<-Read_Attributes(Score_Length,"sequence_length")
      H5Gclose(Score_Length)
      
      #Group4<-"/Analyses/Basecall_1D_000/" ###No more used as sometimes it can have months in english word instead of numbers
      #Time<-H5Gopen(File,Group4)
      #if (H5Aexists(Time,"time_stamp")) {
        #Date<-Read_Attributes(Time,"time_stamp")
        #H5Gclose(Time)
        #Y_M_D<-substr(Date,1,10)
        #H_M_S<-substr(Date,12,19)
        #Time_Vector<-paste(c(Y_M_D,H_M_S), collapse=" ")
        #Table['Unix_Time']<-as.numeric(as.POSIXct(strptime(Time_Vector, "%Y-%m-%d %H:%M:%S")))
      #}
      #else {
        #H5Gclose(Time)
        #Table['Unix_Time']<-"Unix_Time"
      #}
      
      Group5<-"/Raw/Reads"
      Read_Mux<-H5Gopen(File,Group5)
      Template <- h5ls(Read_Mux,recursive=FALSE,datasetinfo=FALSE)
      H5Gclose(Read_Mux)
      Read_Path <- paste0("/Raw/Reads/",Template$name)
      
      Group6<- H5Gopen(File,Read_Path)
      
      Table['Mux']<-Read_Attributes(Group6,"start_mux")
      Table['Read_Id']<-Read_Attributes(Group6,"read_id")
      Start<-Read_Attributes(Group6,"start_time")
      AlternativeStart<-floor(Start/4000) ##actual sampling rate
      H5Gclose(Group6)
      
      ## try to compute a relative time using different parameters ##
      
      
      Group4.2<-"/UniqueGlobalKey/tracking_id"
      Time2<-H5Gopen(File,Group4.2)
      DateUnix2<-Read_Attributes(Time2,"exp_start_time")
      H5Gclose(Time2)
      if (length(unlist(strsplit(DateUnix2,"T")))==2) { ### avoid problems with UNIX exp start times found on EGA samples
        Y_M_D<-substr(DateUnix2,1,10)
        H_M_S<-substr(DateUnix2,12,19)
        Time_Vector<-paste(c(Y_M_D,H_M_S), collapse=" ")
        Table['Unix_Time']<-as.numeric(as.POSIXct(strptime(Time_Vector, "%Y-%m-%d %H:%M:%S")))+AlternativeStart
          
      }
      else {
        Table['Unix_Time']<-(as.numeric(AlternativeStart)+as.numeric(DateUnix2))
      }
        
      
      H5Fclose(File)
      
      return(Table) 
    }
  }
  
  ######################
  
  PassFiles<-NanoPrepareMList[[1]]
  
  ### CALCULATIING ###
  
  if (GCC == TRUE) {
    message("Starting .fast5 files extraction with GC content calculation!")
    cl <- makeCluster(as.numeric(Cores)) 
    clusterExport(cl, c("HDF5_File_Parsing_Table_With_GC","PassFiles","Read_DataSet","Read_Attributes"),envir=environment())
    clusterEvalQ(cl,c(library(rhdf5), library(seqinr)))
    List<-parLapply(cl, c(1:length(PassFiles)), HDF5_File_Parsing_Table_With_GC,PassFiles)
    stopCluster(cl)
    Table_Tot<-data.frame(matrix(unlist(List), nrow=length(List), ncol=7, byrow=TRUE),stringsAsFactors=FALSE)
    colnames(Table_Tot)<-c("Read Id", "Channel Number", "Mux Number", "Unix Time", "Length of Read", "Quality", "GC_Content")
    write.table(Table_Tot, file.path(Directory, paste0(label, "_Information_Table.txt")), col.names=T, row.names=F, quote=F, sep="\t")
    message("Done!")
    return(Table_Tot)
    
  }
  if (GCC == FALSE) {
    message("Starting .fast5 files extraction without GC content calculation!")
    cl <- makeCluster(as.numeric(Cores)) 
    clusterExport(cl, c("HDF5_File_Parsing_Table_Without_GC","PassFiles","Read_Attributes"),envir=environment())
    clusterEvalQ(cl,c(library(rhdf5), library(seqinr)))
    List<-parLapply(cl, c(1:length(PassFiles)), HDF5_File_Parsing_Table_Without_GC,PassFiles)
    stopCluster(cl)
    Table_Tot<-data.frame(matrix(unlist(List), nrow=length(List), ncol=7, byrow=TRUE),stringsAsFactors=FALSE)
    colnames(Table_Tot)<-c("Read Id", "Channel Number", "Mux Number", "Unix Time", "Length of Read", "Quality", "GC_Content")
    write.table(Table_Tot, file.path(Directory, paste0(label, "_Information_Table.txt")), col.names=T, row.names=F, quote=F, sep="\t")
    message("Done!")
    return(Table_Tot)
    
  }
}


############################################ NanoStatsM ############################################

#' @title Plots statistics for your MinION .fast5 files 
#' @description NanoStatsM plots statistics for "Pass" .fast5 files folder given to NanoPrepareM function and returns 4 tables required by NanoCompare.
#' @param NanoPrepareMList The object of class "list" returned by NanoPrepareM function
#' @param NanoMTable The table returned by NanoTableM function
#' @param DataOut Where NanoStatsM results will be saved. Use the same directory specified for NanoTableM function and be sure that it doesn't already contain NanoStatsM/NanoStatsG results
#' @return Plots: \cr 
#' - Cumulative reads and cumulative base pairs (Cumulative_Reads_&_Cumulative_Basepairs.pdf); \cr 
#' - Reads number, base pairs number, reads length (min, max, mean), reads quality (min, max, mean) calculated every half an hour (Reads_Basepairs_Length_Quality.pdf); \cr 
#' - Reads length versus reads quality (Length_versus_Quality.pdf); \cr 
#' - "Pass", "Fail" and "Skip" FAST5 reads number, percentage and "Pass" FAST5 reads GC content (if "GCC = TRUE" is provided to NanoTable function) (Pass_Fail_Skip_and_GC_Content.pdf / Pass_Fail_Skip_NO_GC_Content.pdf); \cr 
#' - Channels and Muxes activity (Channels_and_Muxes_Activity.pdf) with respect to their REAL disposition in the flowcell (more at: https://community.nanoporetech.com/technical_documents/hardware/v/hwtd_5000_v1_revh_03may2016/flow-cell-chip). Inactive channels and muxes are grey-colored.
#' @examples
#' #do not run
#' NanoStatsM(NanoPrepareMList=NanoMList, NanoMTable=NanoMTable, DataOut="/Path/To/DataOutExp")


NanoStatsM<-function(NanoPrepareMList,NanoMTable,DataOut) {
  
  library(reshape2)
  library(scales)
  library(ggplot2)
  library(RColorBrewer)
  library(grid)
  library(gridExtra)
  
  
  Directory<-file.path(DataOut)
  
  TableInDirectory<-list.files(Directory,pattern="Information_Table.txt")
  
  if(length(TableInDirectory) == 0) {
    stop("Use the same directory specified for NanoTableM function")
  }
  
  CumulativeInDirectory<-list.files(Directory,pattern=("Cumulative_Basepairs.pdf"))
  
  if(length(CumulativeInDirectory) != 0) {
    stop("Can't use a directory that already contains NanoStatsM/NanoStatsG results")
  }
  
  label<-as.character(NanoPrepareMList[[4]])
  
  List.Files.HDF5_Pass<-NanoPrepareMList[[1]]
  
  ##### FUNCTIONS ######
  
  Increment <- function(x)
  {
    return(x+8)
  }
  
  Increment2 <- function(x)
  {
    return(x+32)
  }
  
  Increment3<-function(x)
  {
    return(x+128)
  }
  
  rotate<-function(x) 
  { 
    t(apply(x, 1, rev))
  }
  
  define_region <- function(row, col)
  {
    viewport(layout.pos.row = row, layout.pos.col = col)
  }
  
  ######################

  setwd(Directory)
  options(scipen=9999)
  
  
  FilesAnalyzed<-which(as.character(NanoMTable[,1]) != "Read_Id")
  Length_Not_Analyzed<-length(which(as.character(NanoMTable[,1]) == "Read_Id"))
  NanoTable<-NanoMTable[FilesAnalyzed,]
  Really_Pass_File<-which(as.numeric(NanoTable[,6]) >= 7)
  Fail_File_Length<-length(which(as.numeric(NanoTable[,6]) < 7))
  NanoTable<-NanoTable[Really_Pass_File,]
  List.Files.HDF5_Fail_Length<-as.numeric(NanoPrepareMList[[2]])+Length_Not_Analyzed+Fail_File_Length
  List.Files.HDF5_Pass.length<-length(List.Files.HDF5_Pass)-Length_Not_Analyzed-Fail_File_Length
  List.Files.HDF5_Skip_Length<-as.numeric(NanoPrepareMList[[3]])

  write.table(NanoTable, file.path(Directory, paste0(label, "_Information_Table.txt")), col.names=T, row.names=F, quote=F, sep="\t")
  
  Table_HDF5<-NanoTable[,1:6]
  
  Time_2<-as.numeric(Table_HDF5[,4])
  
  Run_Duration<-round(as.numeric(difftime(as.POSIXct(max(Time_2),origin="1/1/1970"), as.POSIXct(min(Time_2), origin="1/1/1970"), units="hours")))
  
  Time_Rescaled <- scales::rescale(Time_2, to=c(0,Run_Duration))
  Table_HDF5_Def<-cbind(Table_HDF5,Time_Rescaled)
  
  colnames(Table_HDF5_Def)<-c("Read", "Channel Number", "Mux Number", "Unix Time", "Length of Read", "Quality", "Relative Experimental Time")
  
  
  Relative_Time<-as.numeric(Table_HDF5_Def[,7])
  Relative_Time_Per_Hours<-seq(from=min(round(Relative_Time)), to=max(round(Relative_Time)), by=0.5)
  Template_Length<-as.numeric(Table_HDF5_Def[,5])
  Quality_Score<-as.numeric(Table_HDF5_Def[,6])
  

  message("Analyzing...")
  
  Reads_Per_Hour<-c()
  Base_Pairs_Per_Hour<-c()
  Max_Length_Per_Hour<-c()
  Mean_Length_Per_Hour<-c()
  Min_Length_Per_Hour<-c()
  Min_Quality_Score_Per_Hour<-c()
  Mean_Quality_Score_Per_Hour<-c()
  Max_Quality_Score_Per_Hour<-c()
  
  
  for (ii in 1:(length(Relative_Time_Per_Hours))) {
    
    if (ii < length(Relative_Time_Per_Hours)) {
      Index_Hours<-which(Relative_Time >= Relative_Time_Per_Hours[ii] & Relative_Time < Relative_Time_Per_Hours[ii+1])
      if (length(Index_Hours) == 0) {
        Reads_Per_Hour[ii]<-0
        Base_Pairs_Per_Hour[ii]<-0
        Mean_Length_Per_Hour[ii]<-0
        Max_Length_Per_Hour[ii]<-0
        Min_Length_Per_Hour[ii]<-0
        Mean_Quality_Score_Per_Hour[ii]<-0
        Min_Quality_Score_Per_Hour[ii]<-0
        Max_Quality_Score_Per_Hour[ii]<-0 
      }
      else
      {
        Reads_Per_Hour[ii]<-length(Index_Hours)
        Base_Pairs_Per_Hour[ii]<-sum(Template_Length[Index_Hours])
        Mean_Length_Per_Hour[ii]<-mean(Template_Length[Index_Hours])
        Max_Length_Per_Hour[ii]<-max(Template_Length[Index_Hours])
        Min_Length_Per_Hour[ii]<-min(Template_Length[Index_Hours])
        Mean_Quality_Score_Per_Hour[ii]<-mean(Quality_Score[Index_Hours])
        Min_Quality_Score_Per_Hour[ii]<-min(Quality_Score[Index_Hours])
        Max_Quality_Score_Per_Hour[ii]<-max(Quality_Score[Index_Hours])
      }
    }
    else {
      Index_Hours<-which(Relative_Time == Relative_Time_Per_Hours[ii])
      
      if (length(Index_Hours) == 0) {
        Reads_Per_Hour[ii]<-0
        Base_Pairs_Per_Hour[ii]<-0
        Mean_Length_Per_Hour[ii]<-0
        Max_Length_Per_Hour[ii]<-0
        Min_Length_Per_Hour[ii]<-0
        Mean_Quality_Score_Per_Hour[ii]<-0
        Min_Quality_Score_Per_Hour[ii]<-0
        Max_Quality_Score_Per_Hour[ii]<-0   
      }
      else {
        Reads_Per_Hour[ii]<-length(Index_Hours)
        Base_Pairs_Per_Hour[ii]<-sum(Template_Length[Index_Hours])
        Mean_Length_Per_Hour[ii]<-mean(Template_Length[Index_Hours])
        Max_Length_Per_Hour[ii]<-max(Template_Length[Index_Hours])
        Min_Length_Per_Hour[ii]<-min(Template_Length[Index_Hours])
        Mean_Quality_Score_Per_Hour[ii]<-mean(Quality_Score[Index_Hours])
        Min_Quality_Score_Per_Hour[ii]<-min(Quality_Score[Index_Hours])
        Max_Quality_Score_Per_Hour[ii]<-max(Quality_Score[Index_Hours])
      }
    }
  }
  
  
  Cumulative_Reads<-cumsum(Reads_Per_Hour)
  Cumulative_Basepairs<-cumsum(Base_Pairs_Per_Hour)
  
  Channel_Vector<-as.numeric(Table_HDF5_Def[,2])
  Mux_Vector<-as.numeric(Table_HDF5_Def[,3])
  Channels_Number<-c(1:512)
  
  
  Base_Pairs_Per_Channel<-c()
  
  Table_HDF5_Reordered<-c()
  
  for (iii in 1:length(Channels_Number)) {
    Ind_Chann<-which(Channel_Vector == Channels_Number[iii])
    Mux_Associated<-sort(Mux_Vector[Ind_Chann], index.return=TRUE)$ix
    if (length(Ind_Chann) == 0) {
      next
    }
    else {
      Table_HDF5_Re<-Table_HDF5_Def[Ind_Chann,][Mux_Associated,]
      Table_HDF5_Reordered<-rbind(Table_HDF5_Reordered,Table_HDF5_Re)
    }
    Base_Pairs_Per_Channel[iii]<-sum(Template_Length[Ind_Chann])
  }
  
  rownames(Table_HDF5_Reordered)<-c()
  
  
  #PLOT CUMULATIVE READS/BP


  message("Plotting...")

  x<-Relative_Time_Per_Hours
  y0.1<-Cumulative_Reads
  data0.1<-data.frame('x'=x,'y'=y0.1)
  data0.1$group<-"Cumulative Reads"
  
  
  Cumulative_Reads_Plot<-ggplot(data0.1, aes(x=x, y=y, group=group, fill=group)) +
    geom_line(size=.5) + 
    scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
    scale_y_continuous(name="Number Of Reads")+
    geom_ribbon(data=subset(data0.1,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
    scale_fill_manual(name='', values=c("Cumulative Reads" = "coral3"))+
    theme_bw(base_size = 12)+
    theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12,face="italic"),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
    theme(legend.position="bottom")+
    ggtitle("Cumulative Reads")
  
  y0.2<-Cumulative_Basepairs
  data0.2<-data.frame('x'=x,'y'=y0.2)
  data0.2$group<-"Cumulative Base Pairs"
  
  Cumulative_Base_Pairs_Plot<-ggplot(data0.2, aes(x=x, y=y, group=group, fill=group)) +
    geom_line(size=.5) + 
    scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
    scale_y_continuous(name="Number Of Base Pairs")+
    geom_ribbon(data=subset(data0.2,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
    scale_fill_manual(name='', values=c("Cumulative Base Pairs" = "darkcyan"))+
    theme_bw(base_size = 12)+
    theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12,face="italic"),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
    theme(legend.position="bottom")+
    ggtitle("Cumulative Base Pairs")
  
  Cumulative_Plot<-arrangeGrob(grid.arrange(Cumulative_Reads_Plot,Cumulative_Base_Pairs_Plot, nrow=2, ncol=1))
  
  ggsave(paste0(label,"_Cumulative_Reads_&_Cumulative_Basepairs.pdf"), device="pdf", Cumulative_Plot, height=10,width=15)
  
  #PLOT PER-HOUR READS/BPs/QUALITY/LENGTH


  y1<-Reads_Per_Hour
  data1<-data.frame('x'=x,'y'=y1)
  data1$group<-"Reads Per Hour"
  
  Reads_Per_Hour_Plot<-ggplot(data1, aes(x=x, y=y, group=group, fill=group)) +
    geom_line(size=.5) + 
    scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
    scale_y_continuous(name="Number Of Reads")+
    geom_ribbon(data=subset(data1,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
    scale_fill_manual(name='', values=c("Reads Per Hour" = "coral3"))+
    theme_bw(base_size = 12)+
    theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
    theme(legend.position="bottom")+
    ggtitle("Number Of Reads")
  
  
  y2<-Base_Pairs_Per_Hour
  data2<-data.frame('x'=x,'y'=y2)
  data2$group<-"Base Pairs Per Hour"
  
  
  Base_Pairs_Per_Hour_Plot<-ggplot(data2, aes(x=x, y=y, group=group, fill=group)) +
    geom_line(size=.5) + 
    scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
    scale_y_continuous(name="Number Of Base Pairs")+
    geom_ribbon(data=subset(data2,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
    scale_fill_manual(name='', values=c("Base Pairs Per Hour" = "darkcyan"))+
    theme_bw(base_size = 12)+
    theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
    theme(legend.position="bottom")+
    ggtitle("Number Of Base Pairs")
  
  
  y3.0<-log10(Mean_Length_Per_Hour)
  data3.0.0<-data.frame('x'=x,'y'=Mean_Length_Per_Hour)
  data3.0<-data.frame('x'=x,'y'=y3.0)
  data3.0$group<-"Mean Length"
  
  y3.1<-log10(Max_Length_Per_Hour)
  data3.1<-data.frame('x'=x,'y'=y3.1)
  data3.1$group<-"Max Length"
  
  y3.2<-log10(Min_Length_Per_Hour)
  data3.2<-data.frame('x'=x,'y'=y3.2)
  data3.2$group<-"Min Length"
  
  data3<-rbind(data3.0, data3.1, data3.2)
  
  Length_Per_Hour_Plot<-ggplot(data3, aes(x=x, y=y, group=group, fill=group)) +
    geom_line(size=.5) + 
    scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
    scale_y_continuous(name="Length", breaks=c(2,3,4,5,6), labels=c("100","1000","10000","100000","1000000"))+
    geom_ribbon(data=subset(data3,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0, alpha=.7) +
    scale_fill_manual(name='', values=c("Mean Length" = "darkolivegreen1", "Min Length" = "darkolivegreen", "Max Length" = "cornsilk"))+
    theme_bw(base_size = 12)+
    theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
    theme(legend.position="bottom")+
    ggtitle("Length")
  
  y4.0<-Mean_Quality_Score_Per_Hour
  data4.0<-data.frame('x'=x,'y'=y4.0)
  data4.0$group<-"Mean Quality"
  
  y4.1<-Min_Quality_Score_Per_Hour
  data4.1<-data.frame('x'=x,'y'=y4.1)
  data4.1$group<-"Min Quality"
  
  y4.2<-Max_Quality_Score_Per_Hour
  data4.2<-data.frame('x'=x,'y'=y4.2)
  data4.2$group<-"Max Quality"
  
  data4<-rbind(data4.0,data4.1,data4.2)
  
  Quality_Score_Per_Hour_Plot<-ggplot(data4, aes(x=x, y=y, group=group, fill=group)) +
    geom_line(size=.5) + 
    scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
    scale_y_continuous(name="Quality")+
    geom_ribbon(data=subset(data4,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,alpha=.7) +
    scale_fill_manual(name='', values=c("Mean Quality" = "chocolate1", "Min Quality" = "chocolate", "Max Quality" = "cornsilk"))+
    theme_bw(base_size = 12)+
    theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
    theme(legend.position="bottom")+
    ggtitle("Quality Score")
  
  
  Others_Plot<-arrangeGrob(grid.arrange(Reads_Per_Hour_Plot,Base_Pairs_Per_Hour_Plot,Length_Per_Hour_Plot,Quality_Score_Per_Hour_Plot, nrow=2, ncol=2))
  
  ggsave(paste0(label,"_Reads_Basepairs_Length_Quality.pdf"), device="pdf", Others_Plot, height=10,width=15)
  
  #PASS/FAIL
  
  blank_theme <- theme_minimal()+
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.border = element_blank(),
      panel.grid=element_blank(),
      axis.ticks = element_blank(),
      plot.title=element_text(size=14, face="bold"),
      axis.text.x=element_blank()
    )
  
  Data_Pass_Fail_Percentage <- data.frame(
    group = c("Pass", "Fail/Skip"),
    value = c((List.Files.HDF5_Pass.length/(List.Files.HDF5_Pass.length+List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length)), ((List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length)/(List.Files.HDF5_Pass.length+List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length)))
  )
  
  
  Data_Pass_Fail_Percentage_Plot<-ggplot(Data_Pass_Fail_Percentage, aes(x="", y=value, fill=group))+
    geom_bar(width = 1, size = 1, color = "white", stat = "identity")+
    geom_text(aes(label = scales::percent(value)), position = position_stack(vjust = 0.5))+
    coord_polar("y", start=0) +
    scale_fill_brewer(palette="Dark2") +
    blank_theme+
    theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.title=element_blank(),legend.position="bottom")+
    ggtitle("Passed and Failed/Skipped Percentage")
  
  
  Data_Pass_Fail_Tot <- data.frame(
    group = c("Pass", "Fail/Skip"),
    value = c(List.Files.HDF5_Pass.length, (List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length))
  )
  
  Data_Pass_Fail_Tot_Plot<-ggplot(Data_Pass_Fail_Tot, aes(x="", y=value, fill=group))+
    geom_bar(width = 1, size = 1, color = "white", stat = "identity")+
    geom_text(aes(label = value), position = position_stack(vjust = 0.5))+
    coord_polar("y", start=0) +
    scale_fill_brewer(palette="Accent") +
    blank_theme+
    theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.title=element_blank(), legend.position="bottom")+
    ggtitle("Passed and Failed/Skipped Number")
  
  #WILL BE SAVED WITH GC CONTENT
  
  
  ###################### LENGTH_VS_QUALITY ######################
  
  Tot_Length<-data.frame(Template_Length)
  Tot_Quality<-data.frame(Quality_Score)
  
  
  ScatterTheme <- list(labs(x="Length",y="Quality"),theme_bw(), theme(legend.position=c(1,0),legend.justification=c(1,0), legend.background=element_blank(),legend.direction="horizontal", legend.title=element_text(face="bold.italic"),axis.title=element_text(face="italic")))
  
  
  hist_top_mean_length<-ggplot(Tot_Length, aes(x=Template_Length))+theme_bw()+ geom_histogram(aes(y = ..count../1000),col="darkolivegreen", fill="darkolivegreen1",boundary = min(Tot_Length$Template_Length))+labs(x="",y="Count (x 1e3)")+scale_x_continuous(limits=c(min(Tot_Length$Template_Length),max(Tot_Length$Template_Length)))+theme(axis.title=element_text(face="italic"))
  hist_right_mean_quality<-ggplot(Tot_Quality, aes(x=Quality_Score))+ theme_bw()+ geom_histogram(aes(y = ..count../1000),col="chocolate", fill="chocolate1",boundary = min(Tot_Quality$Quality_Score))+ labs(x="",y="Count (x 1e3)")+coord_flip()+scale_x_continuous(limits=c(min(Tot_Quality$Quality_Score),max(Tot_Quality$Quality_Score)))+theme(axis.title=element_text(face="italic"))
  empty <- ggplot()+geom_point(aes(1,1), colour="white")+
    theme(axis.ticks=element_blank(), 
          panel.background=element_blank(), 
          axis.text.x=element_blank(), axis.text.y=element_blank(),           
          axis.title.x=element_blank(), axis.title.y=element_blank())
  scatter <- ggplot(data.frame(cbind(Tot_Length$Template_Length,Tot_Quality$Quality_Score)),aes(x=Tot_Length$Template_Length, y=Tot_Quality$Quality_Score))+geom_point(col="grey27", size=.09, alpha=.4)+scale_x_continuous(limits=c(min(Tot_Length$Template_Length),max(Tot_Length$Template_Length)))+scale_y_continuous(limits=c(min(Tot_Quality$Quality_Score),max(Tot_Quality$Quality_Score)))+stat_density2d(aes(col=..level.., alpha=..level..)) + scale_color_continuous(low="darkblue",high="darkred") +geom_smooth(method=lm,linetype=2, size=.5,col="black",se=F) + guides(alpha="none",col=guide_legend(title="Density"))+ ScatterTheme
  
  
  
  
  Length_VS_Quality_Plot<-grid.arrange(hist_top_mean_length, empty, scatter, hist_right_mean_quality, ncol=2, nrow=2, widths=c(4,1), heights=c(1, 4))
  
  
  ggsave(paste0(label,"_Length_versus_Quality.pdf"), device="pdf", Length_VS_Quality_Plot, height=10,width=15)
  
  
  # MUX PRODUCTIVITY PER CHANNEL
  
  Mux_Numbers<-c(1:4)
  
  Chan<-as.numeric(Table_HDF5_Reordered[,2])
  Mu<-as.numeric(Table_HDF5_Reordered[,3])
  Le<-as.numeric(Table_HDF5_Reordered[,5])
  
  List_Of_Mux<-list()
  
  for (iii in 1:length(Channels_Number)) {
    Ind_Chann<-which(Chan == Channels_Number[iii])
    Mux_Associated_Number<-sort(Mu[Ind_Chann])
    Table_Mux<-c()
    for (lll in 1:length(Mux_Numbers)) {
      Ind_Mux<-which(Mux_Associated_Number == Mux_Numbers[lll])
      Chan_Mux<-Chan[Ind_Chann][Ind_Mux]
      if (length(Chan_Mux) == 0) {
        Mux<-NA
        Lenght_Per_Mux<-NA
        Table_Mu<-cbind(NA, NA, NA)
        Table_Mux<-rbind(Table_Mux,Table_Mu)
      }
      else {
        Mux<-Mu[Ind_Chann][Ind_Mux]
        Lenght_Per_Mux<-sum(Le[Ind_Chann][Ind_Mux])
        Table_Mu<-cbind(unique(Chan_Mux), unique(Mux),Lenght_Per_Mux)
        Table_Mux<-rbind(Table_Mux,Table_Mu)
      }
    }
    List_Of_Mux[[iii]]<-Table_Mux
  }
  
  Table_Mux_Def<-do.call(rbind,List_Of_Mux)
  
  
  colnames(Table_Mux_Def)<-c("Channel Number", "Mux Number", "Total Reads Produced Per Mux")
  
  #PLOT CORRELATION MATRIXES (CHANNEL AND MUXES)
  
  m1<-matrix(Base_Pairs_Per_Channel[1:32], ncol=8, nrow=4, byrow=TRUE)
  m2<-matrix(Base_Pairs_Per_Channel[449:480], ncol=8, nrow=4, byrow=TRUE)
  m3<-matrix(Base_Pairs_Per_Channel[385:416], ncol=8, nrow=4, byrow=TRUE)
  m4<-matrix(Base_Pairs_Per_Channel[321:352], ncol=8, nrow=4, byrow=TRUE)
  m5<-matrix(Base_Pairs_Per_Channel[257:288], ncol=8, nrow=4, byrow=TRUE)
  m6<-matrix(Base_Pairs_Per_Channel[193:224], ncol=8, nrow=4, byrow=TRUE)
  m7<-matrix(Base_Pairs_Per_Channel[129:160], ncol=8, nrow=4, byrow=TRUE)
  m8<-matrix(Base_Pairs_Per_Channel[65:96], ncol=8, nrow=4, byrow=TRUE)
  mdef3<-rbind(m1,m2,m3,m4,m5,m6,m7,m8)
  m9<-rotate(matrix(Base_Pairs_Per_Channel[33:64], ncol=8, nrow=4, byrow=TRUE))
  m10<-rotate(matrix(Base_Pairs_Per_Channel[481:512], ncol=8, nrow=4, byrow=TRUE))
  m11<-rotate(matrix(Base_Pairs_Per_Channel[417:448], ncol=8, nrow=4, byrow=TRUE))
  m12<-rotate(matrix(Base_Pairs_Per_Channel[353:384], ncol=8, nrow=4, byrow=TRUE))
  m13<-rotate(matrix(Base_Pairs_Per_Channel[289:320], ncol=8, nrow=4, byrow=TRUE))
  m14<-rotate(matrix(Base_Pairs_Per_Channel[225:256], ncol=8, nrow=4, byrow=TRUE))
  m15<-rotate(matrix(Base_Pairs_Per_Channel[161:192], ncol=8, nrow=4, byrow=TRUE))
  m16<-rotate(matrix(Base_Pairs_Per_Channel[97:128], ncol=8, nrow=4, byrow=TRUE))
  mdef4<-rbind(m9,m10,m11,m12,m13,m14,m15,m16)
  Matrixbpchannel<-cbind(mdef3,mdef4)
  
  BasePairs_Per_Mux<-as.numeric(Table_Mux_Def[,3])
  
  First_Eight_Disposition<-c(3,4,1,2,6,5,8,7)
  Second_Eight_Disposition<-Increment(First_Eight_Disposition)
  Third_Eight_Disposition<-Increment(Second_Eight_Disposition)
  Fouth_Eight_Disposition<-Increment(Third_Eight_Disposition)
  First_Line<-c(First_Eight_Disposition,Second_Eight_Disposition,Third_Eight_Disposition,Fouth_Eight_Disposition)
  Second_Line<-Increment2(First_Line)
  Third_Line<-Increment2(Second_Line)
  Fourth_Line<-Increment2(Third_Line)
  First_Block<-c(First_Line,Second_Line,Third_Line,Fourth_Line)
  Second_Block<-Increment3(First_Block)
  Third_Block<-Increment3(Second_Block)
  Fourth_Block<-Increment3(Third_Block)
  Fifth_Block<-Increment3(Fourth_Block)
  Sixth_Block<-Increment3(Fifth_Block)
  Seventh_Block<-Increment3(Sixth_Block)
  Eight_Block<-Increment3(Seventh_Block)
  Ninth_Block<-Increment3(Eight_Block)
  Tenth_Block<-Increment3(Ninth_Block)
  Eleventh_Block<-Increment3(Tenth_Block)
  Twelfth_Block<-Increment3(Eleventh_Block)
  Thirtheenth_Block<-Increment3(Twelfth_Block)
  Fourtheenth_Block<-Increment3(Thirtheenth_Block)
  Fiftheenth_Block<-Increment3(Fourtheenth_Block)
  Sixtheenth_Block<-Increment3(Fiftheenth_Block)
  
  M1<-matrix(BasePairs_Per_Mux[First_Block], ncol= 32, nrow= 4, byrow=TRUE)
  M2<-matrix(BasePairs_Per_Mux[Fiftheenth_Block], ncol= 32, nrow= 4, byrow=TRUE)
  M3<-matrix(BasePairs_Per_Mux[Thirtheenth_Block], ncol= 32, nrow= 4, byrow=TRUE)
  M4<-matrix(BasePairs_Per_Mux[Eleventh_Block], ncol= 32, nrow= 4, byrow=TRUE)
  M5<-matrix(BasePairs_Per_Mux[Ninth_Block], ncol= 32, nrow= 4, byrow=TRUE)
  M6<-matrix(BasePairs_Per_Mux[Seventh_Block], ncol= 32, nrow= 4, byrow=TRUE)
  M7<-matrix(BasePairs_Per_Mux[Fifth_Block], ncol= 32, nrow= 4, byrow=TRUE)
  M8<-matrix(BasePairs_Per_Mux[Third_Block], ncol= 32, nrow= 4, byrow=TRUE)
  Mdef3<-rbind(M1,M2,M3,M4,M5,M6,M7,M8)
  M9<-rotate(matrix(BasePairs_Per_Mux[Second_Block], ncol= 32, nrow= 4, byrow=TRUE))
  M10<-rotate(matrix(BasePairs_Per_Mux[Sixtheenth_Block],ncol= 32, nrow= 4, byrow=TRUE))
  M11<-rotate(matrix(BasePairs_Per_Mux[Fourtheenth_Block], ncol= 32, nrow= 4, byrow=TRUE))
  M12<-rotate(matrix(BasePairs_Per_Mux[Twelfth_Block], ncol= 32, nrow= 4, byrow=TRUE))
  M13<-rotate(matrix(BasePairs_Per_Mux[Tenth_Block], ncol= 32, nrow= 4, byrow=TRUE))
  M14<-rotate(matrix(BasePairs_Per_Mux[Eight_Block], ncol= 32, nrow= 4, byrow=TRUE))
  M15<-rotate(matrix(BasePairs_Per_Mux[Sixth_Block], ncol= 32, nrow= 4, byrow=TRUE))
  M16<-rotate(matrix(BasePairs_Per_Mux[Fourth_Block], ncol= 32, nrow= 4, byrow=TRUE))
  Mdef4<-rbind(M9,M10,M11,M12,M13,M14,M15,M16)
  MatrixMuxActivity<-cbind(Mdef3,Mdef4)
  
  
  #PLOTTING "FALSE" CORRELATION MATRIXES
  
  Palette <- colorRampPalette(brewer.pal(9, "Reds"))
  
  adjMatrixbpchannel<-melt(rotate(t(Matrixbpchannel)))
  Plot_Channel_Activity<-ggplot(data=adjMatrixbpchannel, aes(x=Var1, y=Var2)) +
    geom_tile(aes(fill=value), color="white", size=2)+
    scale_fill_gradientn(colours= Palette(4), na.value="grey70",limits=c(min(adjMatrixbpchannel[,3], na.rm=TRUE), max(adjMatrixbpchannel[,3], na.rm=TRUE))) +
    theme(axis.line=element_blank(),axis.text.x=element_blank(),
          axis.text.y=element_blank(),axis.ticks=element_blank(),
          axis.title.x=element_blank(),
          axis.title.y=element_blank(),legend.position="bottom",
          legend.title=element_text(face="bold.italic"),
          panel.background=element_blank(),panel.border=element_blank(),panel.grid.major=element_blank(),
          panel.grid.minor=element_blank(),plot.background=element_blank(),legend.text=element_text(size=10),
          plot.title = element_text(hjust = 0.5,face="bold.italic",size=16),legend.text.align = 0)+
    guides(fill = guide_colorbar(barwidth= 61,barheight=.5,title="Base Pairs Productivity", title.position="top",title.hjust=0.5))+
    ggtitle("Channels Activity")
  
  adjMatrixMuxActivity<-melt(rotate(t(MatrixMuxActivity)))
  Plot_Mux_Activity<-ggplot(data=adjMatrixMuxActivity, aes(x=Var1, y=Var2)) +
    geom_tile(aes(fill=value), color="white", size=2)+
    scale_fill_gradientn(colours=Palette(4), na.value="grey70",limits=c(min(adjMatrixMuxActivity[,3], na.rm=TRUE), max(adjMatrixMuxActivity[,3], na.rm=TRUE))) +
    theme(axis.line=element_blank(),axis.text.x=element_blank(),
          axis.text.y=element_blank(),axis.ticks=element_blank(),
          axis.title.x=element_blank(),
          axis.title.y=element_blank(),legend.position="bottom",
          legend.title=element_text(face="bold.italic"),
          panel.background=element_blank(),panel.border=element_blank(),panel.grid.major=element_blank(),
          panel.grid.minor=element_blank(),plot.background=element_blank(),legend.text=element_text(size=10),
          plot.title = element_text(hjust = 0.5,face="bold.italic",size=16))+
    guides(fill = guide_colorbar(barwidth= 61, barheight=.5,title="Base Pairs Productivity", title.position="top",title.hjust=0.5))+
    ggtitle("Muxes Activity")
  
  
  Plot_Tot<-grid.arrange(arrangeGrob(Plot_Channel_Activity,Plot_Mux_Activity,nrow=2, ncol=1, widths=15, heights=c(12,12)))
  
  ggsave(paste0(label,"_Channels_and_Muxes_Activity.pdf"), device="pdf",Plot_Tot, height=10, width=18)
  
  
  ###PLOT GC CONTENT#######
  
  if (NanoTable[1,7] == "GC_Content") {
    
    pdf(paste0(label,"_Pass_Fail_Skip_NO_GC_Content.pdf"), height=10, width=15, onefile=TRUE)
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(1, 2)))
    print(Data_Pass_Fail_Percentage_Plot, vp=define_region(1, 1))
    print(Data_Pass_Fail_Tot_Plot, vp = define_region(1, 2))
    dev.off()
  }
  
  else {
    
    GC_Content_To_Plot<-as.numeric(NanoTable[,7])
    Hist_GC_Content<-ggplot(data.frame(GC_Content_To_Plot), aes(x=GC_Content_To_Plot))+theme_bw()+ geom_histogram(col="midnightblue", fill="cyan4")+labs(x="",y="Count")+ggtitle("GC Content")+theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=16), axis.title.y=element_text(face="italic"))
    pdf(paste0(label,"_Pass_Fail_Skip_and_GC_Content.pdf"), height=10, width=15, onefile=TRUE)
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(2, 2)))
    print(Data_Pass_Fail_Percentage_Plot, vp=define_region(1, 1))
    print(Data_Pass_Fail_Tot_Plot, vp = define_region(1, 2))
    print(Hist_GC_Content, vp = define_region(2, 1:2))
    dev.off()
  }
  
  #save data for other analyses
  
  write.table(data1, file.path(Directory, paste0(label, "_ReadsProduced.txt")),col.names=T, sep="\t")
  write.table(data2, file.path(Directory, paste0(label, "_BasePairsProduced.txt")),col.names=T, sep="\t")
  write.table(data3.0.0, file.path(Directory, paste0(label, "_MeanLength.txt")),col.names=T, sep="\t")
  write.table(data4.0, file.path(Directory, paste0(label, "_MeanQuality.txt")),col.names=T, sep="\t")

  message("Done!")
  
}


############################################ NanoFastqM ############################################

#' @title Extracts .fastq informations from your MinION "Pass" .fast5 files
#' @description NanoFastqM returns a file text containing .fastq sequences (and, if you want, an additional file text containing .fasta sequences) extracted from your "Pass" .fsat5 reads.
#' @param DataPass Path to "Pass" .fast5 files folder (can find .fast5 files recursively)
#' @param DataOut Where your .fastq (and .fasta) file will be saved
#' @param Label A lable used to identify .fastq (and .fasta) file outputted
#' @param Cores Number of cores to be used: 1 by default
#' @param FASTA Logical. If FALSE (by default), return only .fastq file else, if TRUE, return both .fastq and .fasta files
#' @return .fastq file and, if you wish, .fasta file for your "Pass" .fast5 files.
#' @examples
#' #do not run
#' NanoFastqM(DataPass="Path/To/DataPass", DataOut="/Path/To/DataOutExp", Cores=6, FASTA=FALSE)
#' NanoFastqM(DataPass="Path/To/DataPass", DataOut="/Path/To/DataOutExp", Cores=6, FASTA=TRUE)


NanoFastqM<-function(DataPass,DataOut,Label,Cores=1,FASTA=FALSE) {
  
  library(rhdf5)
  library(parallel)
  library(ShortRead)
  
  Directory<-file.path(DataOut)
  dir.create(Directory,showWarnings=FALSE)
  setwd(Directory)
  
  label<-as.character(Label)
  PassFiles<-list.files(DataPass, full.names=TRUE, recursive = TRUE, pattern=".fast5")
  
  
  ### FUNCTIONS ###
  
  Read_DataSet<-function(File, PathGroup) { 
    h5errorHandling(type="suppress")
    Data1<-H5Dopen(File, PathGroup) 
    Data2<-H5Dread(Data1)
    H5Dclose(Data1)
    return(Data2) 
  }
  
  Read_Attributes<-function(PathGroup, Attribute) { 
    h5errorHandling(type="suppress")
    Data1<-H5Aopen(PathGroup, Attribute)
    Data2<-H5Aread(Data1)
    H5Aclose(Data1)
    return(Data2) 
  } 
  
  Fastq_Extraction<-function(i,File) {
    
    
    Fastq<-list()
    
    h5errorHandling(type="suppress")
    File<-H5Fopen(File[i])
    
    GroupTry<-"/Analyses/Basecall_1D_000/BaseCalled_template/Fastq"
    
    Try<-try(Read_DataSet(File,GroupTry), silent=TRUE) #exclude not-basecalled .fast5 files
    
    if (inherits(Try,"try-error")) {
      H5Fclose(File)
      Fastq[[i]]<-NA
      return(Fastq[[i]])
    }
    
    else {
      
      Group0<-"/Analyses/Basecall_1D_000/Summary/basecall_1d_template"
      Score<-H5Gopen(File,Group0)
      Quality<-Read_Attributes(Score,"mean_qscore")
      H5Gclose(Score)
      
      if (Quality >= 7) { 
        Pre_Fastq<-Read_DataSet(File,GroupTry)
        Fastq[[i]]<- strsplit(Pre_Fastq,split="\n",fixed=TRUE)[[1]]
      }
      
      else
      {
        Fastq[[i]]<-NA
      }
      H5Fclose(File)
      return(Fastq[[i]])
    }
  }
  
  ################################
  
  
  if (FASTA == FALSE) {
    message("Starting .fastq sequences extraction!")
  }
  else {
    message("Starting .fastq sequences and .fasta sequences extraction!")
  }
  
  cl <- makeCluster(as.numeric(Cores)) 
  clusterExport(cl, c("Fastq_Extraction","PassFiles","Read_DataSet","Read_Attributes"),envir=environment())
  clusterEvalQ(cl,library(rhdf5))
  List<-parLapply(cl, c(1:length(PassFiles)),Fastq_Extraction,PassFiles)
  stopCluster(cl)
  FastqTot<-do.call(c,List)
  FastqClean<-which(is.na(FastqTot) == FALSE)
  FastqFinal<-(FastqTot[FastqClean])
  message("Writing .fastq file!")
  fileConn<-file(paste0(label,".fastq"))
  writeLines(FastqFinal,fileConn)
  close(fileConn)
  
  
  if (FASTA == TRUE) {
    message("Writing .fasta file!")
    Fastq = FastqStreamer(file.path(Directory,paste0(label,".fastq")))
    repeat {
      Fasta = yield(Fastq)
      if (length(Fasta) == 0) break
      writeFasta(Fasta, file=file.path(Directory,paste0(label,".fasta")), mode="a")
    }
  }
  message("Done!") 
}



############################################ GridION DATA ANALYSIS  ############################################


############################################ NanoPrepareG ############################################



#' @title Prepares GridION X5 data for your analyses with NanoR
#' @description NanoPrepareG generates an object of class "list" that contains informations required by other functions from NanoR when analyzing GridION X5 data.
#' @param BasecalledFast5 Logical. Have your experiment returned basecalled .fast5 files (BasecalledFast5=TRUE)? By default GridION X5 outputs .fastq, sequencing summary .txt files and non-basecalled .fast5 files (that's why BasecalledFast5 is, by default, set to FALSE).
#' @param Data Path to the GridION X5 folder that includes .fastq and sequencing summary files (if BasecalledFast5 = FALSE) or to basecalled .fast5 files (if BasecalledFast5 = TRUE)
#' @param DataSkip Path to "Skip" .fast5 files folder (can find .fast5 files recursively); non-basecalled reads (considered "Skipped") are stored in /data/reads/[FlowCellId]/[ExperimentId]/fast5/[FolderNumber]
#' @param DataFail Path to "Fail" .fast5 files folder (can find .fast5 files recursively); can be provided, for example, if working with .fast5 basecalled with ONT's Albacore
#' @param Cores The number of cores to be used to accelerate sequencing summary files reading (useful only if BasecalledFast5 is set to FALSE)
#' @param Label A label that will be used, together with the Flow Cell identifier extracted from the inputted data, to identify your experiment
#' @details If working with .fastq files and sequencing summary files, DataSkip can be omitted (in that case the number of skipped data is considered to be 0) while the number of failed reads is automatically computed by NanoR. If working with basecalled .fast5 files, DataFail can be omitted but, in this case, the number of failed .fast5 files is considered to be 0.
#' @return Object of class "list" containing informations required by NanoTableG and NanoStatsG functions.
#' @examples
#' #do not run
#' #when working with sequencing summary files and .fastq files
#' NanoGList<-NanoPrepareG(BasecalledFast5=FALSE, Data="/data/basecalled/ExperimentName/FlowCellId", DataSkip="/data/reads/[FlowCellId]/[ExperimentId]/fast5/" Label="Ex", Cores=3)
#' #when working with basecalled .fast5 files
#' Pass<-"Path/to/workspace/pass"
#' Fail<-"Path/to/workspace/fail"
#' NanoGList<-NanoPrepareG(BasecalledFast5=TRUE, Data=Pass, DataFail=Fail, Label="Ex")



NanoPrepareG<-function(BasecalledFast5=FALSE,Data,DataFail=NA,DataSkip=NA,Cores=1, Label) {
  
  if(BasecalledFast5 == FALSE) {

  	library(parallel)
    
    FastqFiles<-list.files(Data,pattern=".fastq",full.names=TRUE, recursive=TRUE)
    FastqFilesPathOrdered<-FastqFiles[order(as.numeric(gsub("[^0-9]+", "", FastqFiles)))]
    message("Found ",length(FastqFiles), " .fastq files in folder!")
    
    
    SummariesFiles<-list.files(Data,full.names=TRUE,pattern="sequencing_summary", recursive=TRUE)
    SummariesFilesOrdered<-SummariesFiles[order(as.numeric(gsub("[^0-9]+", "", SummariesFiles)))]
    
    message("Found ",length(SummariesFiles), " sequencing summary files in folder!")
    message("Reading and organizing sequencing summary files...")
    
    Read_Table_Summary<-function(i,File) {
      Table<-read.table(File[i],header=FALSE,sep="\t",skip=1)
      RealativeTimeToAdd<-(as.numeric(Table[,8])+as.numeric(Table[,10]))## calculate a relative time that will be rescaled
      SummaryTable<-cbind(Table,RealativeTimeToAdd)
      Flowcell_ID_Label<-unlist(strsplit(as.character(Table[,1]),"_"))[4]
      Flowcell_ID<-rep(Flowcell_ID_Label,dim(Table)[1])
      Read_Id<-as.character(Table[,2])
      Channel<-as.numeric(Table[,4])
      Length<-as.numeric(Table[,11])
      Qscore<-as.numeric(Table[,12])
      Relative_Time<-as.numeric(SummaryTable[,14])
      Table<-cbind(Flowcell_ID,Read_Id,Channel,Relative_Time,Length,Qscore)
      return(Table)
    }
    
    
    cl <- makeCluster(as.numeric(Cores)) 
    clusterExport(cl, c("Read_Table_Summary","SummariesFiles"),envir=environment())
    List<-parLapply(cl, c(1:length(SummariesFiles)),Read_Table_Summary,SummariesFiles)
    stopCluster(cl)
    
    SummaryTable<-do.call(rbind,List)
    
    colnames(SummaryTable)<-c("Flowcell ID","Read Id","Channel Number","Relative Time","Length of Read","Quality")
    Fast5Data<-NA
    DataSkip_Length<-0
    DataFail_Length<-0
    label<-as.character(Label)
    
    
    message("Done!")
  }
  
  if (BasecalledFast5 == TRUE) {
    FastqFilesPathOrdered<-NA
    SummaryTable<-NA
    Fast5Data<-list.files(Data,recursive=TRUE,full.names=TRUE,pattern=".fast5")
    message("Found ",length(Fast5Data), " .fast5 files in folder!")
    if(is.na(DataFail)) {
      DataFail_Length<-0
      message("No failed .fast5 files folder specified.")
    }
    else {
      DataFail_Length<-length(list.files(DataFail,recursive=TRUE,full.names=TRUE,pattern=".fast5"))
      message("Found ",DataFail_Length, " failed .fast5 files in folder!")
    }
    if (is.na(DataSkip)) {
      DataSkip_Length<-0
      message("No skipped .fast5 files folder specified.")
    }
    else {
      DataSkip_Length<-length(list.files(DataSkip,recursive=TRUE,full.names=TRUE,pattern=".fast5"))
      message("Found ",length(SkippedData), " skipped .fast5 files in folder!")
    }
    label<-as.character(Label)
    message("Done!")
  }
  
  List<-list(FastqFilesPathOrdered,SummaryTable,Fast5Data,DataFail_Length,DataSkip_Length,label)
  return(List)
  
}



############################################ NanoTableG ############################################


#' @title Generates an information table for your GridION X5 .fast5 files
#' @description NanoTableG generates a table that contains useful informations for each read identified by NanoPrepareG function. When analyzing GridION X5 basecalled .fast5 files, metadata extraction can be accelerated using multiple cores. Please note that sometimes .fastq files returned by GridION X5 can be ill-formatted: in that case, NanoTableG will stop and you can run this function again after set GCC to FALSE. This problem is avoided if basecalled .fast5 files are used.
#' @param NanoPrepareGList The object of class "list" returned by NanoPrepareG function;
#' @param DataOut Where the table will be saved. Don't use a directory that already contains NanoTableG (or NanoTableM) result;
#' @param GCC Logical. If TRUE (by default), NanoTableG computes GC content for each read
#' @param Cores Number of cores to be used to accelerate metadata extraction from basecalled .fast5 files. Doesn't affect time when dealing with .fastq and sequencing summary files.
#' @return Table containing informations required by NanoStatsG and NanoCompare (and useful for users who want to analyze these data by theirselves!).
#' @examples
#' #do not run
#' #when working with sequencing summary files and .fastq files
#' NanoGTable<-NanoTableG(NanoPrepareGList=NanoGList, DataOut="/Path/To/DataOutEx", GCC=TRUE) #set GCC to "FALSE" on error
#' #when working with basecalled .fast5 files
#' NanoGTable<-NanoTableG(NanoPrepareGList=NanoGList, DataOut="/Path/To/DataOutEx", GCC=TRUE, Cores=6) #accelerate using multiple cores 




NanoTableG<-function(NanoPrepareGList,DataOut,Cores=1,GCC=TRUE) {
  
  Directory<-file.path(DataOut)
  dir.create(Directory,showWarnings=FALSE)
  Label<-NanoPrepareGList[[6]]
  
  if (is.na(NanoPrepareGList[[1]][1]) == FALSE & is.na(NanoPrepareGList[[3]][1])) {
    
    
    Table<-NanoPrepareGList[[2]]
    
    Flowcell_ID_Label<-unique(as.character(Table[,1]))
    if (Flowcell_ID_Label == "GA10000") {
      Flowcell_ID_Label<-as.character("FC1")
    }
    if (Flowcell_ID_Label == "GA20000") {
      Flowcell_ID_Label<-as.character("FC2")
    }
    if (Flowcell_ID_Label == "GA30000") {
      Flowcell_ID_Label<-as.character("FC3")
    }
    if (Flowcell_ID_Label == "GA40000") {
      Flowcell_ID_Label<-as.character("FC4")
    }
    if (Flowcell_ID_Label == "GA50000") {
      Flowcell_ID_Label<-as.character("FC5")
    }
    Flowcell_ID<-rep(Flowcell_ID_Label,dim(Table)[1])
    Read_Id<-as.character(Table[,2])
    Channel<-as.numeric(Table[,3])
    Length<-as.numeric(Table[,5])
    Qscore<-as.numeric(Table[,6])
    Relative_Time<-as.numeric(Table[,4])
    
    if (GCC == TRUE) {
      
      
      library(ShortRead)
      library(seqinr)
      message("Extracting .fastq sequences and calculating GC content...")
      
      
      FastqFilesPath<-NanoPrepareGList[[1]]
      
      Content<-function(CharRead) {
        Gc<-GC(s2c(CharRead))
        return(Gc)
      }
      
      
      Gc_Con<-function(Element) {
        fqFile<-FastqFile(Element)
        Fastq <- tryCatch({
          readFastq(fqFile)},
          error = function(cond) {
            return(NULL)},
          warning = function(cond) {
            message(cond)
            return(NULL)}
        )
        if (is.null(Fastq)) {
          stop(paste0("Ill-formatted .fastq file: fastq", i-1, ". Analysis aborted. Retry NanoTableG setting GCC to FALSE!"))
        }
        else {
          CharRead<-as.character(sread(Fastq))
          close(fqFile)
          Gc<-lapply(CharRead,Content)
        }
        return(Gc)
      }
      
      List<-lapply(FastqFilesPath,Gc_Con)
      
      
      GC_Content<-unlist(List)
      
      if (length(GC_Content) != dim(Table)[1]) { ##lack of some fastq sequences
        LackOfReads<-dim(Table)[1]-length(GC_Content)
        message(LackOfReads," missing GC content counts: creating ",LackOfReads," fake GC content count...")
        GC_To_Add<-sample(GC_Content,LackOfReads)
        GC_Content<-c(GC_Content,GC_To_Add)
      }
      
      Table_Tot<-cbind(Flowcell_ID,Read_Id,Channel,Relative_Time,Length,Qscore,GC_Content)
      colnames(Table_Tot)<-c("Flowcell ID","Read Id","Channel Number","Relative Time","Length of Read","Quality", "GC content")
      write.table(Table_Tot, file.path(DataOut, paste0(Label,"_",Flowcell_ID_Label,"_Information_Table.txt")), sep="\t", quote=FALSE,col.names=T, row.names=FALSE) 
      message("Information Table with GC content count created and saved at ",file.path(Directory), "!")
    }
    
    else {
      
      
      GC_Content<-rep("GC_Content",dim(Table)[1])
      Table_Tot<-cbind(Flowcell_ID,Read_Id,Channel,Relative_Time,Length,Qscore,GC_Content)
      colnames(Table_Tot)<-c("Flowcell ID","Read Id","Channel Number","Relative Time","Length of Read","Quality", "GC content")
      write.table(Table_Tot, file.path(DataOut, paste0(Label,"_",Flowcell_ID_Label,"_Information_Table.txt")), sep="\t", quote=FALSE,col.names=T, row.names=FALSE) 
      message("Information Table without GC content count created and saved at ",file.path(Directory), "!")
    }
    
    return(Table_Tot)
  }
  
  else {
    
    Fast5Data<-NanoPrepareGList[[3]]
    
    library(rhdf5)
    library(seqinr)
    
    
    Read_DataSet<-function(File, PathGroup) { 
      h5errorHandling(type="suppress")
      Data1<-H5Dopen(File, PathGroup) 
      Data2<-H5Dread(Data1)
      H5Dclose(Data1)
      return(Data2) 
    }
    
    Read_Attributes<-function(PathGroup, Attribute) { 
      h5errorHandling(type="suppress")
      
      Data1<-H5Aopen(PathGroup, Attribute)
      Data2<-H5Aread(Data1)
      H5Aclose(Data1)
      return(Data2) 
    }     
    
    HDF5_File_Parsing_Table_With_GC<-function(i,File) {  ## work for R9.4 and R9.5
      
      h5errorHandling(type="suppress")
      Table<-c(FlowCell_Id="FlowCell_Id",Read_Id="Read_Id",Channel="Channel",Mux="Mux",Unix_Time="Unix_Time",Length="Length",Qscore="Qscore",GC_Content="GC_Content")
      
      File<-H5Fopen(File[i])
      
      Group1<-"/Analyses/Basecall_1D_000/BaseCalled_template/Fastq"
      Try<-try(Read_DataSet(File,Group1), silent=TRUE) #exclude non-basecalled .fast5 reads (will be counted as failed by NanoStats)
      if (inherits(Try,"try-error")) {
        return(Table)
      }
      
      else {
        
        Pre_Fastq<-Read_DataSet(File,Group1)
        Sequence_Fastq<-unlist(strsplit(Pre_Fastq,"\n"))[2]
        Fastq<-s2c(Sequence_Fastq)
        Table['GC_Content']<-GC(Fastq)
        
        Group2<-"/UniqueGlobalKey/channel_id"
        Chann_File<-H5Gopen(File,Group2)
        Table['Channel']<-Read_Attributes(Chann_File,"channel_number")
        H5Gclose(Chann_File)
        
        Group3<-"/Analyses/Basecall_1D_000/Summary/basecall_1d_template"
        Score_Length<-H5Gopen(File,Group3)
        Table['Qscore']<-Read_Attributes(Score_Length,"mean_qscore")
        Table['Length']<-Read_Attributes(Score_Length,"sequence_length")
        H5Gclose(Score_Length)
        
        #Group4<-"/Analyses/Basecall_1D_000/" ###No more used as sometimes it can have months in english word instead of numbers
        #Time<-H5Gopen(File,Group4)
        #if (H5Aexists(Time,"time_stamp")) {
        #Date<-Read_Attributes(Time,"time_stamp")
        #H5Gclose(Time)
        #Y_M_D<-substr(Date,1,10)
        #H_M_S<-substr(Date,12,19)
        #Time_Vector<-paste(c(Y_M_D,H_M_S), collapse=" ")
        #Table['Unix_Time']<-as.numeric(as.POSIXct(strptime(Time_Vector, "%Y-%m-%d %H:%M:%S")))
        #}
        #else {
        #H5Gclose(Time)
        #Table['Unix_Time']<-"Unix_Time"
        #}
        
        Group5<-"/Raw/Reads"
        Read_Mux<-H5Gopen(File,Group5)
        Template <- h5ls(Read_Mux,recursive=FALSE,datasetinfo=FALSE)
        H5Gclose(Read_Mux)
        Read_Path <- paste0("/Raw/Reads/",Template$name)
        
        Group6<- H5Gopen(File,Read_Path)
        
        Table['Mux']<-Read_Attributes(Group6,"start_mux")
        Table['Read_Id']<-Read_Attributes(Group6,"read_id")
        Start<-Read_Attributes(Group6,"start_time")
        AlternativeStart<-floor(Start/4000) ##actual sampling rate
        H5Gclose(Group6)
        
        ## try to compute a relative time using different parameters ##
        
        
        Group4.2<-"/UniqueGlobalKey/tracking_id"
        Time2<-H5Gopen(File,Group4.2)
        DateUnix2<-Read_Attributes(Time2,"exp_start_time")
        FlowcellId<-Read_Attributes(Time2, "device_id")
        Table['FlowCell_Id']<-FlowcellId
        H5Gclose(Time2)
        if (length(unlist(strsplit(DateUnix2,"T")))==2) {### avoid problems with UNIX exp start times found on EGA samples
          Y_M_D<-substr(DateUnix2,1,10)
          H_M_S<-substr(DateUnix2,12,19)
          Time_Vector<-paste(c(Y_M_D,H_M_S), collapse=" ")
          Table['Unix_Time']<-as.numeric(as.POSIXct(strptime(Time_Vector, "%Y-%m-%d %H:%M:%S")))+AlternativeStart
          
        }
        else {
          Table['Unix_Time']<-(as.numeric(AlternativeStart)+as.numeric(DateUnix2))
        }
        
        
        H5Fclose(File)
        
        return(Table) 
      }
    }
    
    HDF5_File_Parsing_Table_Without_GC<-function(i,File) {  ## work for R9.4 and R9.5
      
      h5errorHandling(type="suppress")
      Table<-c(FlowCell_Id="FlowCell_Id",Read_Id="Read_Id",Channel="Channel",Mux="Mux",Unix_Time="Unix_Time",Length="Length",Qscore="Qscore",GC_Content="GC_Content")
      
      File<-H5Fopen(File[i])
      
      Group1<-"/Analyses/Basecall_1D_000/BaseCalled_template/Fastq"
      Try<-try(Read_DataSet(File,Group1), silent=TRUE) #exclude not-basecalled .fast5 files (will be counted as failed by NanoStats)
      if (inherits(Try,"try-error")) {
        return(Table)
      }
      
      else {
        
        
        Table['GC_Content']<-'GC_Content'
        
        Group2<-"/UniqueGlobalKey/channel_id"
        Chann_File<-H5Gopen(File,Group2)
        Table['Channel']<-Read_Attributes(Chann_File,"channel_number")
        H5Gclose(Chann_File)
        
        Group3<-"/Analyses/Basecall_1D_000/Summary/basecall_1d_template"
        Score_Length<-H5Gopen(File,Group3)
        Table['Qscore']<-Read_Attributes(Score_Length,"mean_qscore")
        Table['Length']<-Read_Attributes(Score_Length,"sequence_length")
        H5Gclose(Score_Length)
        
        #Group4<-"/Analyses/Basecall_1D_000/" ###No more used as sometimes it can have months in english word instead of numbers
        #Time<-H5Gopen(File,Group4)
        #if (H5Aexists(Time,"time_stamp")) {
        #Date<-Read_Attributes(Time,"time_stamp")
        #H5Gclose(Time)
        #Y_M_D<-substr(Date,1,10)
        #H_M_S<-substr(Date,12,19)
        #Time_Vector<-paste(c(Y_M_D,H_M_S), collapse=" ")
        #Table['Unix_Time']<-as.numeric(as.POSIXct(strptime(Time_Vector, "%Y-%m-%d %H:%M:%S")))
        #}
        #else {
        #H5Gclose(Time)
        #Table['Unix_Time']<-"Unix_Time"
        #}
        
        Group5<-"/Raw/Reads"
        Read_Mux<-H5Gopen(File,Group5)
        Template <- h5ls(Read_Mux,recursive=FALSE,datasetinfo=FALSE)
        H5Gclose(Read_Mux)
        Read_Path <- paste0("/Raw/Reads/",Template$name)
        
        Group6<- H5Gopen(File,Read_Path)
        
        Table['Mux']<-Read_Attributes(Group6,"start_mux")
        Table['Read_Id']<-Read_Attributes(Group6,"read_id")
        Start<-Read_Attributes(Group6,"start_time")
        AlternativeStart<-floor(Start/4000) ##actual sampling rate
        H5Gclose(Group6)
        
        ## try to compute a relative time using different parameters ##
        
        
        Group4.2<-"/UniqueGlobalKey/tracking_id"
        Time2<-H5Gopen(File,Group4.2)
        DateUnix2<-Read_Attributes(Time2,"exp_start_time")
        FlowcellId<-Read_Attributes(Time2, "device_id")
        Table['FlowCell_Id']<-FlowcellId
        H5Gclose(Time2)
        if (length(unlist(strsplit(DateUnix2,"T")))==2) { ### avoid problems with UNIX exp start times found on EGA samples
          Y_M_D<-substr(DateUnix2,1,10)
          H_M_S<-substr(DateUnix2,12,19)
          Time_Vector<-paste(c(Y_M_D,H_M_S), collapse=" ")
          Table['Unix_Time']<-as.numeric(as.POSIXct(strptime(Time_Vector, "%Y-%m-%d %H:%M:%S")))+AlternativeStart
          
        }
        else {
          Table['Unix_Time']<-(as.numeric(AlternativeStart)+as.numeric(DateUnix2))
        }
        
        
        H5Fclose(File)
        
        return(Table) 
      }
    }
    
    if (GCC == TRUE) {
      message("Starting .fast5 files extraction with GC content calculation!")
      cl <- makeCluster(as.numeric(Cores)) 
      clusterExport(cl, c("HDF5_File_Parsing_Table_With_GC","Fast5Data","Read_DataSet","Read_Attributes"),envir=environment())
      clusterEvalQ(cl,c(library(rhdf5), library(seqinr)))
      List<-parLapply(cl, c(1:length(Fast5Data)), HDF5_File_Parsing_Table_With_GC,Fast5Data)
      stopCluster(cl)
      Table_Tot<-data.frame(matrix(unlist(List), nrow=length(List), ncol=8, byrow=TRUE),stringsAsFactors=FALSE)
      Flowcell_ID_Label<-unique(as.character(Table_Tot[,1]))
      if (Flowcell_ID_Label == "GA10000") {
        Flowcell_ID_Label<-as.character("FC1")
      }
      if (Flowcell_ID_Label == "GA20000") {
        Flowcell_ID_Label<-as.character("FC2")
      }
      if (Flowcell_ID_Label == "GA30000") {
        Flowcell_ID_Label<-as.character("FC3")
      }
      if (Flowcell_ID_Label == "GA40000") {
        Flowcell_ID_Label<-as.character("FC4")
      }
      if (Flowcell_ID_Label == "GA50000") {
        Flowcell_ID_Label<-as.character("FC5")
      }
      Table_Tot<-cbind(rep(Flowcell_ID_Label,nrow(Table_Tot)),Table_Tot[,2:8])
      colnames(Table_Tot)<-c("Flowcell Id","Read Id", "Channel Number", "Mux Number", "Unix Time", "Length of Read", "Quality", "GC_Content")
      write.table(Table_Tot, file.path(Directory, paste0(Label,"_",Flowcell_ID_Label, "_Information_Table.txt")), col.names=T, row.names=F, quote=F, sep="\t")
      message("Done!")
      return(Table_Tot)
      
    }
    if (GCC == FALSE) {
      message("Starting .fast5 files extraction without GC content calculation!")
      cl <- makeCluster(as.numeric(Cores)) 
      clusterExport(cl, c("HDF5_File_Parsing_Table_Without_GC","Fast5Data","Read_Attributes"),envir=environment())
      clusterEvalQ(cl,c(library(rhdf5), library(seqinr)))
      List<-parLapply(cl, c(1:length(Fast5Data)), HDF5_File_Parsing_Table_Without_GC,Fast5Data)
      stopCluster(cl)
      Table_Tot<-data.frame(matrix(unlist(List), nrow=length(List), ncol=8, byrow=TRUE),stringsAsFactors=FALSE)
      Flowcell_ID_Label<-unique(as.character(Table_Tot[,1]))
      if (Flowcell_ID_Label == "GA10000") {
        Flowcell_ID_Label<-as.character("FC1")
      }
      if (Flowcell_ID_Label == "GA20000") {
        Flowcell_ID_Label<-as.character("FC2")
      }
      if (Flowcell_ID_Label == "GA30000") {
        Flowcell_ID_Label<-as.character("FC3")
      }
      if (Flowcell_ID_Label == "GA40000") {
        Flowcell_ID_Label<-as.character("FC4")
      }
      if (Flowcell_ID_Label == "GA50000") {
        Flowcell_ID_Label<-as.character("FC5")
      }
      Table_Tot<-cbind(rep(Flowcell_ID_Label,nrow(Table_Tot)),Table_Tot[,2:8])
      colnames(Table_Tot)<-c("Flowcell Id","Read Id", "Channel Number", "Mux Number", "Unix Time", "Length of Read", "Quality", "GC_Content")
      write.table(Table_Tot, file.path(Directory, paste0(Label,"_",Flowcell_ID_Label, "_Information_Table.txt")), col.names=T, row.names=F, quote=F, sep="\t")
      message("Done!")
      return(Table_Tot)
      
    }
  }
}


############################################ NanoStatsG ############################################


#' @title Plots statistics for your GridION X5 .fast5 files 
#' @description NanoStatsG plots statistics for sequences with quality greater (or equal) to 7 returned from GridION X5 and outputs 4 tables required by NanoCompare.
#' @param NanoPrepareGList The object of class "list" returned by NanoPrepareG function
#' @param NanoGTable The table returned by NanoTableG function
#' @param DataOut Where NanoStatsG results will be saved. Use the same directory specified for NanoTableG function and be sure that it doesn't already contain NanoStatsM/NanoStatsG results
#' @return Plots: \cr 
#' - Cumulative reads and cumulative base pairs (Cumulative_Reads_&_Cumulative_Basepairs.pdf); \cr 
#' - Reads number, base pairs number, reads length (min, max, mean), reads quality (min, max, mean) calculated every half an hour (Reads_Basepairs_Length_Quality.pdf); \cr 
#' - Reads length versus reads quality (Length_versus_Quality.pdf); \cr 
#' - "Pass", "Fail" and "Skip" reads number, percentage and reads GC content count (if "GCC = TRUE" is provided to NanoTableG function) (Pass_Fail_Skip_and_GC_Content.pdf / Pass_Fail_Skip_NO_GC_Content.pdf); \cr 
#' - Channels activity (and muxes activity if analyzing basecalled .fast5 files) (Channels_Activity.pdf / Channels_and_Muxes_Activity.pdf) with respect to their REAL disposition in the flowcell (more at: https://community.nanoporetech.com/technical_documents/hardware/v/hwtd_5000_v1_revh_03may2016/flow-cell-chip). Not-working channels and muxes are grey-colored.
#' @examples
#' #do not run
#' #knows how to deal with different inputs type autonomously 
#' NanoStatsG(NanoPrepareGList=NanoGList, NanoGTable=NanoGTable, DataOut="/Path/To/DataOutEx")



NanoStatsG<-function(NanoPrepareGList,NanoGTable,DataOut) {
  
  library(reshape2)
  library(scales)
  library(ggplot2)
  library(RColorBrewer)
  library(grid)
  library(gridExtra)
  
  
  Increment <- function(x)
  {
    return(x+8)
  }
  
  Increment2 <- function(x)
  {
    return(x+32)
  }
  
  Increment3<-function(x)
  {
    return(x+128)
  }
  
  rotate<-function(x) 
  { 
    t(apply(x, 1, rev))
  }
  
  define_region <- function(row,col)
  {
    viewport(layout.pos.row = row, layout.pos.col = col)
  }
  
  
  
  Directory<-file.path(DataOut)
  dir.create(Directory, showWarnings = FALSE)
  setwd(Directory)
  TableInDirectory<-list.files(Directory,pattern="Information_Table")
  
  if(length(TableInDirectory) == 0) {
    stop("Use the same directory specified for NanoTableG function")
  }
  
  CumulativeInDirectory<-list.files(Directory,pattern=("Cumulative_Basepairs.pdf"))
  
  if(length(CumulativeInDirectory) != 0) {
    stop("Can't use a directory that already contains NanoStatsM/NanoStatsG results")
  }
  
  options(scipen=9999)
  Label<-NanoPrepareGList[[6]]
  
  
  if (is.na(NanoPrepareGList[[1]][1]) == FALSE & is.na(NanoPrepareGList[[3]][1])) {
    
    
    label<-unique(as.character(NanoGTable[,1]))
    
    Really_Pass_File<-which(as.numeric(NanoGTable[,6]) >= 7)
    Fail_File_Length<-length(which(as.numeric(NanoGTable[,6]) < 7))
    NanoTable2<-NanoGTable[Really_Pass_File,]
    List.Files.HDF5_Fail_Length<-as.numeric(NanoPrepareGList[[4]])+Fail_File_Length
    List.Files.HDF5_Pass.length<-dim(NanoGTable)[1]-Fail_File_Length
    List.Files.HDF5_Skip_Length<-as.numeric(NanoPrepareGList[[5]])
    
    
    write.table(NanoTable2, file.path(Directory, paste0(Label,"_",label, "_Information_Table.txt")), col.names=T, row.names=F, quote=F, sep="\t")
    
    
    Table_HDF5<-NanoTable2[,1:6]
    row.names(Table_HDF5)<-c()
    
    Time_2<-as.numeric(Table_HDF5[,4])
    Run_Duration<-round(as.numeric(difftime(as.POSIXct(max(Time_2),origin="1/1/1970"), as.POSIXct(min(Time_2), origin="1/1/1970"), units="hours")))
    Time_Rescaled <- scales::rescale(Time_2, to=c(0,Run_Duration))
    
    Table_HDF5_Def<-cbind(Table_HDF5,Time_Rescaled)
    colnames(Table_HDF5_Def)<-c("Flowcell ID","Read Id","Channel Number","Relative Time","Length of Read","Quality","Relative Experimental Time")
    
    
    Relative_Time<-as.numeric(Table_HDF5_Def[,7])
    Relative_Time_Per_Hours<-seq(from=min(round(Relative_Time)), to=max(round(Relative_Time)), by=0.5)
    Template_Length<-as.numeric(Table_HDF5_Def[,5])
    Quality_Score<-as.numeric(Table_HDF5_Def[,6])
    
    
    message("Analyzing...")
    
    Reads_Per_Hour<-c()
    Base_Pairs_Per_Hour<-c()
    Max_Length_Per_Hour<-c()
    Mean_Length_Per_Hour<-c()
    Min_Length_Per_Hour<-c()
    Min_Quality_Score_Per_Hour<-c()
    Mean_Quality_Score_Per_Hour<-c()
    Max_Quality_Score_Per_Hour<-c()
    
    
    
    for (ii in 1:(length(Relative_Time_Per_Hours))) {
      
      if (ii < length(Relative_Time_Per_Hours)) {
        Index_Hours<-which(Relative_Time >= Relative_Time_Per_Hours[ii] & Relative_Time < Relative_Time_Per_Hours[ii+1])
        if (length(Index_Hours) == 0) {
          Reads_Per_Hour[ii]<-0
          Base_Pairs_Per_Hour[ii]<-0
          Mean_Length_Per_Hour[ii]<-0
          Max_Length_Per_Hour[ii]<-0
          Min_Length_Per_Hour[ii]<-0
          Mean_Quality_Score_Per_Hour[ii]<-0
          Min_Quality_Score_Per_Hour[ii]<-0
          Max_Quality_Score_Per_Hour[ii]<-0 
        }
        else
        {
          Reads_Per_Hour[ii]<-length(Index_Hours)
          Base_Pairs_Per_Hour[ii]<-sum(Template_Length[Index_Hours])
          Mean_Length_Per_Hour[ii]<-mean(Template_Length[Index_Hours])
          Max_Length_Per_Hour[ii]<-max(Template_Length[Index_Hours])
          Min_Length_Per_Hour[ii]<-min(Template_Length[Index_Hours])
          Mean_Quality_Score_Per_Hour[ii]<-mean(Quality_Score[Index_Hours])
          Min_Quality_Score_Per_Hour[ii]<-min(Quality_Score[Index_Hours])
          Max_Quality_Score_Per_Hour[ii]<-max(Quality_Score[Index_Hours])
        }
      }
      else {
        Index_Hours<-which(Relative_Time == Relative_Time_Per_Hours[ii])
        
        if (length(Index_Hours) == 0) {
          Reads_Per_Hour[ii]<-0
          Base_Pairs_Per_Hour[ii]<-0
          Mean_Length_Per_Hour[ii]<-0
          Max_Length_Per_Hour[ii]<-0
          Min_Length_Per_Hour[ii]<-0
          Mean_Quality_Score_Per_Hour[ii]<-0
          Min_Quality_Score_Per_Hour[ii]<-0
          Max_Quality_Score_Per_Hour[ii]<-0   
        }
        else {
          Reads_Per_Hour[ii]<-length(Index_Hours)
          Base_Pairs_Per_Hour[ii]<-sum(Template_Length[Index_Hours])
          Mean_Length_Per_Hour[ii]<-mean(Template_Length[Index_Hours])
          Max_Length_Per_Hour[ii]<-max(Template_Length[Index_Hours])
          Min_Length_Per_Hour[ii]<-min(Template_Length[Index_Hours])
          Mean_Quality_Score_Per_Hour[ii]<-mean(Quality_Score[Index_Hours])
          Min_Quality_Score_Per_Hour[ii]<-min(Quality_Score[Index_Hours])
          Max_Quality_Score_Per_Hour[ii]<-max(Quality_Score[Index_Hours])
        }
      }
    }
    
    
    Cumulative_Reads<-cumsum(Reads_Per_Hour)
    Cumulative_Basepairs<-cumsum(Base_Pairs_Per_Hour)
    
    Channel_Vector<-as.numeric(Table_HDF5_Def[,3])
    Channels_Number<-c(1:512)
    
    
    Base_Pairs_Per_Channel<-c()
    
    Table_HDF5_Reordered<-c()
    
    for (iii in 1:length(Channels_Number)) {
      Ind_Chann<-which(Channel_Vector == Channels_Number[iii])
      if (length(Ind_Chann) == 0) {
        next
      }
      else {
        Table_HDF5_Re<-Table_HDF5_Def[Ind_Chann,]
        Table_HDF5_Reordered<-rbind(Table_HDF5_Reordered,Table_HDF5_Re)
      }
      Base_Pairs_Per_Channel[iii]<-sum(Template_Length[Ind_Chann])
    }
    
    rownames(Table_HDF5_Reordered)<-c()
    
    
    message("Plotting...")
    
    x<-Relative_Time_Per_Hours
    y0.1<-Cumulative_Reads
    data0.1<-data.frame('x'=x,'y'=y0.1)
    data0.1$group<-"Cumulative Reads"
    
    
    Cumulative_Reads_Plot<-ggplot(data0.1, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Number Of Reads")+
      geom_ribbon(data=subset(data0.1,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
      scale_fill_manual(name='', values=c("Cumulative Reads" = "coral3"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12,face="italic"),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Cumulative Reads")
    
    y0.2<-Cumulative_Basepairs
    data0.2<-data.frame('x'=x,'y'=y0.2)
    data0.2$group<-"Cumulative Base Pairs"
    
    Cumulative_Base_Pairs_Plot<-ggplot(data0.2, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Number Of Base Pairs")+
      geom_ribbon(data=subset(data0.2,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
      scale_fill_manual(name='', values=c("Cumulative Base Pairs" = "darkcyan"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12,face="italic"),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Cumulative Base Pairs")
    
    Cumulative_Plot<-arrangeGrob(grid.arrange(Cumulative_Reads_Plot,Cumulative_Base_Pairs_Plot, nrow=2, ncol=1))
    
    ggsave(paste0(Label,"_",label,"_Cumulative_Reads_&_Cumulative_Basepairs.pdf"), device="pdf", Cumulative_Plot, height=10,width=15)
    
    #PLOT PER-HOUR READS/BPs/QUALITY/LENGTH
    
    y1<-Reads_Per_Hour
    data1<-data.frame('x'=x,'y'=y1)
    data1$group<-"Reads Per Hour"
    
    Reads_Per_Hour_Plot<-ggplot(data1, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Number Of Reads")+
      geom_ribbon(data=subset(data1,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
      scale_fill_manual(name='', values=c("Reads Per Hour" = "coral3"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Number Of Reads")
    
    
    y2<-Base_Pairs_Per_Hour
    data2<-data.frame('x'=x,'y'=y2)
    data2$group<-"Base Pairs Per Hour"
    
    
    Base_Pairs_Per_Hour_Plot<-ggplot(data2, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Number Of Base Pairs")+
      geom_ribbon(data=subset(data2,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
      scale_fill_manual(name='', values=c("Base Pairs Per Hour" = "darkcyan"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Number Of Base Pairs")
    
    
    y3.0<-log10(Mean_Length_Per_Hour)
    data3.0.0<-data.frame('x'=x,'y'=Mean_Length_Per_Hour)
    data3.0<-data.frame('x'=x,'y'=y3.0)
    data3.0$group<-"Mean Length"
    
    y3.1<-log10(Max_Length_Per_Hour)
    data3.1<-data.frame('x'=x,'y'=y3.1)
    data3.1$group<-"Max Length"
    
    y3.2<-log10(Min_Length_Per_Hour)
    data3.2<-data.frame('x'=x,'y'=y3.2)
    data3.2$group<-"Min Length"
    
    data3<-rbind(data3.0, data3.1, data3.2)
    
    Length_Per_Hour_Plot<-ggplot(data3, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Length", breaks=c(2,3,4,5,6), labels=c("100","1000","10000","100000","1000000"))+
      geom_ribbon(data=subset(data3,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,alpha=.7) +
      scale_fill_manual(name='', values=c("Mean Length" = "darkolivegreen1", "Min Length" = "darkolivegreen", "Max Length" = "cornsilk"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Length")
    
    y4.0<-Mean_Quality_Score_Per_Hour
    data4.0<-data.frame('x'=x,'y'=y4.0)
    data4.0$group<-"Mean Quality"
    
    y4.1<-Min_Quality_Score_Per_Hour
    data4.1<-data.frame('x'=x,'y'=y4.1)
    data4.1$group<-"Min Quality"
    
    y4.2<-Max_Quality_Score_Per_Hour
    data4.2<-data.frame('x'=x,'y'=y4.2)
    data4.2$group<-"Max Quality"
    
    data4<-rbind(data4.0,data4.1,data4.2)
    
    Quality_Score_Per_Hour_Plot<-ggplot(data4, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Quality")+
      geom_ribbon(data=subset(data4,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,alpha=.7) +
      scale_fill_manual(name='', values=c("Mean Quality" = "chocolate1", "Min Quality" = "chocolate", "Max Quality" = "cornsilk"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Quality Score")
    
    
    Others_Plot<-arrangeGrob(grid.arrange(Reads_Per_Hour_Plot,Base_Pairs_Per_Hour_Plot,Length_Per_Hour_Plot,Quality_Score_Per_Hour_Plot, nrow=2, ncol=2))
    
    ggsave(paste0(Label,"_",label,"_Reads_Basepairs_Length_Quality.pdf"), device="pdf", Others_Plot, height=10,width=15)
    
    
    #PASS/FAIL
    
    blank_theme <- theme_minimal()+
      theme(
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.border = element_blank(),
        panel.grid=element_blank(),
        axis.ticks = element_blank(),
        plot.title=element_text(size=14, face="bold"),
        axis.text.x=element_blank()
      )
    
    Data_Pass_Fail_Percentage <- data.frame(
      group = c("Pass", "Fail/Skip"),
      value = c((List.Files.HDF5_Pass.length/(List.Files.HDF5_Pass.length+List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length)), ((List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length)/(List.Files.HDF5_Pass.length+List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length)))
    )
    
    
    Data_Pass_Fail_Percentage_Plot<-ggplot(Data_Pass_Fail_Percentage, aes(x="", y=value, fill=group))+
      geom_bar(width = 1, size = 1, color = "white", stat = "identity")+
      geom_text(aes(label = scales::percent(value)), position = position_stack(vjust = 0.5))+
      coord_polar("y", start=0) +
      scale_fill_brewer(palette="Dark2") +
      blank_theme+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.title=element_blank(),legend.position="bottom")+
      ggtitle("Passed and Failed/Skipped Percentage")
    
    
    Data_Pass_Fail_Tot <- data.frame(
      group = c("Pass", "Fail/Skip"),
      value = c(List.Files.HDF5_Pass.length, (List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length))
    )
    
    Data_Pass_Fail_Tot_Plot<-ggplot(Data_Pass_Fail_Tot, aes(x="", y=value, fill=group))+
      geom_bar(width = 1, size = 1, color = "white", stat = "identity")+
      geom_text(aes(label = value), position = position_stack(vjust = 0.5))+
      coord_polar("y", start=0) +
      scale_fill_brewer(palette="Accent") +
      blank_theme+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.title=element_blank(), legend.position="bottom")+
      ggtitle("Passed and Failed/Skipped Number")
    
    
    ###################### LENGTH VS QUALITY ######################
    
    Tot_Length<-data.frame(Template_Length)
    Tot_Quality<-data.frame(Quality_Score)
    
    
    ScatterTheme <- list(labs(x="Length",y="Quality"),theme_bw(), theme(legend.position=c(1,0),legend.justification=c(1,0), legend.background=element_blank(),legend.direction="horizontal", legend.title=element_text(face="bold.italic"),axis.title=element_text(face="italic")))
    
    
    hist_top_mean_length<-ggplot(Tot_Length, aes(x=Template_Length))+theme_bw()+ geom_histogram(aes(y = ..count../1000),col="darkolivegreen", fill="darkolivegreen1",boundary = min(Tot_Length$Template_Length))+labs(x="",y="Count (x 1e3)")+scale_x_continuous(limits=c(min(Tot_Length$Template_Length),max(Tot_Length$Template_Length)))+theme(axis.title=element_text(face="italic"))
    hist_right_mean_quality<-ggplot(Tot_Quality, aes(x=Quality_Score))+ theme_bw()+ geom_histogram(aes(y = ..count../1000),col="chocolate", fill="chocolate1",boundary = min(Tot_Quality$Quality_Score))+ labs(x="",y="Count (x 1e3)")+coord_flip()+scale_x_continuous(limits=c(min(Tot_Quality$Quality_Score),max(Tot_Quality$Quality_Score)))+theme(axis.title=element_text(face="italic"))
    empty <- ggplot()+geom_point(aes(1,1), colour="white")+
      theme(axis.ticks=element_blank(), 
            panel.background=element_blank(), 
            axis.text.x=element_blank(), axis.text.y=element_blank(),           
            axis.title.x=element_blank(), axis.title.y=element_blank())
    scatter <- ggplot(data.frame(cbind(Tot_Length$Template_Length,Tot_Quality$Quality_Score)),aes(x=Tot_Length$Template_Length, y=Tot_Quality$Quality_Score))+geom_point(col="grey27", size=.09, alpha=.4)+scale_x_continuous(limits=c(min(Tot_Length$Template_Length),max(Tot_Length$Template_Length)))+scale_y_continuous(limits=c(min(Tot_Quality$Quality_Score),max(Tot_Quality$Quality_Score)))+stat_density2d(aes(col=..level.., alpha=..level..)) + scale_color_continuous(low="darkblue",high="darkred") +geom_smooth(method=lm,linetype=2, size=.5,col="black",se=F) + guides(alpha="none",col=guide_legend(title="Density"))+ ScatterTheme
    
    
    
    
    Length_VS_Quality_Plot<-grid.arrange(hist_top_mean_length, empty, scatter, hist_right_mean_quality, ncol=2, nrow=2, widths=c(4,1), heights=c(1, 4))
    
    
    ggsave(paste0(Label,"_",label,"_Length_versus_Quality.pdf"), device="pdf", Length_VS_Quality_Plot, height=10,width=15)
    
    
    
    ### skip muxes rapresentation
    
    
    #PLOT CORRELATION MATRIXES (CHANNEL AND MUXES)
    
    m1<-matrix(Base_Pairs_Per_Channel[1:32], ncol=8, nrow=4, byrow=TRUE)
    m2<-matrix(Base_Pairs_Per_Channel[449:480], ncol=8, nrow=4, byrow=TRUE)
    m3<-matrix(Base_Pairs_Per_Channel[385:416], ncol=8, nrow=4, byrow=TRUE)
    m4<-matrix(Base_Pairs_Per_Channel[321:352], ncol=8, nrow=4, byrow=TRUE)
    m5<-matrix(Base_Pairs_Per_Channel[257:288], ncol=8, nrow=4, byrow=TRUE)
    m6<-matrix(Base_Pairs_Per_Channel[193:224], ncol=8, nrow=4, byrow=TRUE)
    m7<-matrix(Base_Pairs_Per_Channel[129:160], ncol=8, nrow=4, byrow=TRUE)
    m8<-matrix(Base_Pairs_Per_Channel[65:96], ncol=8, nrow=4, byrow=TRUE)
    mdef3<-rbind(m1,m2,m3,m4,m5,m6,m7,m8)
    m9<-rotate(matrix(Base_Pairs_Per_Channel[33:64], ncol=8, nrow=4, byrow=TRUE))
    m10<-rotate(matrix(Base_Pairs_Per_Channel[481:512], ncol=8, nrow=4, byrow=TRUE))
    m11<-rotate(matrix(Base_Pairs_Per_Channel[417:448], ncol=8, nrow=4, byrow=TRUE))
    m12<-rotate(matrix(Base_Pairs_Per_Channel[353:384], ncol=8, nrow=4, byrow=TRUE))
    m13<-rotate(matrix(Base_Pairs_Per_Channel[289:320], ncol=8, nrow=4, byrow=TRUE))
    m14<-rotate(matrix(Base_Pairs_Per_Channel[225:256], ncol=8, nrow=4, byrow=TRUE))
    m15<-rotate(matrix(Base_Pairs_Per_Channel[161:192], ncol=8, nrow=4, byrow=TRUE))
    m16<-rotate(matrix(Base_Pairs_Per_Channel[97:128], ncol=8, nrow=4, byrow=TRUE))
    mdef4<-rbind(m9,m10,m11,m12,m13,m14,m15,m16)
    Matrixbpchannel<-cbind(mdef3,mdef4)
    
    
    #PLOTTING "FALSE" CORRELATION MATRIXES
    
    Palette <- colorRampPalette(brewer.pal(9, "Reds"))
    
    adjMatrixbpchannel<-melt(rotate(t(Matrixbpchannel)))
    Plot_Channel_Activity<-ggplot(data=adjMatrixbpchannel, aes(x=Var1, y=Var2)) +
      geom_tile(aes(fill=value), color="white", size=2)+
      scale_fill_gradientn(colours= Palette(4), na.value="grey70",limits=c(min(adjMatrixbpchannel[,3], na.rm=TRUE), max(adjMatrixbpchannel[,3], na.rm=TRUE))) +
      theme(axis.line=element_blank(),axis.text.x=element_blank(),
            axis.text.y=element_blank(),axis.ticks=element_blank(),
            axis.title.x=element_blank(),
            axis.title.y=element_blank(),legend.position="bottom",
            legend.title=element_text(face="bold.italic"),
            panel.background=element_blank(),panel.border=element_blank(),panel.grid.major=element_blank(),
            panel.grid.minor=element_blank(),plot.background=element_blank(),legend.text=element_text(size=10),
            plot.title = element_text(hjust = 0.5,face="bold.italic",size=16),legend.text.align = 0)+
      guides(fill = guide_colorbar(barwidth= 61,barheight=.5,title="Base Pairs Productivity", title.position="top",title.hjust=0.5))+
      ggtitle("Channels Activity")
    
    ggsave(paste0(Label,"_",label,"_Channels_Activity.pdf"), device="pdf",Plot_Channel_Activity, height=10, width=18)
    
    
    ###PLOT GC CONTENT#######
    
    
    
    if (NanoTable2[1,7] == "GC_Content") {
      
      pdf(paste0(Label,"_",label,"_Pass_Fail_Skip_NO_GC_Content.pdf"), height=10, width=15, onefile=TRUE)
      grid.newpage()
      pushViewport(viewport(layout = grid.layout(1, 2)))
      print(Data_Pass_Fail_Percentage_Plot, vp=define_region(1, 1))
      print(Data_Pass_Fail_Tot_Plot, vp = define_region(1, 2))
      dev.off()
    }
    
    else {
      
      GC_Content_To_Plot<-as.numeric(NanoTable2[,7])
      Hist_GC_Content<-ggplot(data.frame(GC_Content_To_Plot), aes(x=GC_Content_To_Plot))+theme_bw()+ geom_histogram(col="midnightblue", fill="cyan4")+labs(x="",y="Count")+ggtitle("GC Content")+theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=16), axis.title.y=element_text(face="italic"))
      pdf(paste0(Label,"_",label,"_Pass_Fail_Skip_and_GC_Content.pdf"), height=10, width=15, onefile=TRUE)
      grid.newpage()
      pushViewport(viewport(layout = grid.layout(2, 2)))
      print(Data_Pass_Fail_Percentage_Plot, vp=define_region(1, 1))
      print(Data_Pass_Fail_Tot_Plot, vp = define_region(1, 2))
      print(Hist_GC_Content, vp = define_region(2, 1:2))
      dev.off()
    }
    
    #save data for other analyses
    
    write.table(data1, file.path(Directory, paste0(Label,"_",label, "_ReadsProduced.txt")),col.names=T, sep="\t")
    write.table(data2, file.path(Directory, paste0(Label,"_",label, "_BasePairsProduced.txt")),col.names=T, sep="\t")
    write.table(data3.0.0, file.path(Directory, paste0(Label,"_",label, "_MeanLength.txt")),col.names=T, sep="\t")
    write.table(data4.0, file.path(Directory, paste0(Label,"_",label, "_MeanQuality.txt")),col.names=T, sep="\t")
    
    message("Done!")
    
  }
  
  else {
    
    
    label<-unique(as.character(NanoGTable[,1]))
    NanoGTable<-NanoGTable[,2:8]
    FilesAnalyzed<-which(as.character(NanoGTable[,1]) != "Read_Id")
    Length_Not_Analyzed<-length(which(as.character(NanoGTable[,1]) == "Read_Id"))
    NanoTable<-NanoGTable[FilesAnalyzed,]
    Really_Pass_File<-which(as.numeric(NanoTable[,6]) >= 7)
    Fail_File_Length<-length(which(as.numeric(NanoTable[,6]) < 7))
    NanoTable<-NanoTable[Really_Pass_File,]
    List.Files.HDF5_Fail_Length<-as.numeric(NanoPrepareGList[[4]])+Length_Not_Analyzed+Fail_File_Length
    List.Files.HDF5_Pass.length<-length(NanoPrepareGList[[3]])-Length_Not_Analyzed-Fail_File_Length
    List.Files.HDF5_Skip_Length<-as.numeric(NanoPrepareGList[[5]])
    
    write.table(NanoTable, file.path(Directory, paste0(Label,"_",label, "_Information_Table.txt")), col.names=T, row.names=F, quote=F, sep="\t")
    
    Table_HDF5<-NanoTable[,1:6]
    
    Time_2<-as.numeric(Table_HDF5[,4])
    
    Run_Duration<-round(as.numeric(difftime(as.POSIXct(max(Time_2),origin="1/1/1970"), as.POSIXct(min(Time_2), origin="1/1/1970"), units="hours")))
    
    Time_Rescaled <- scales::rescale(Time_2, to=c(0,Run_Duration))
    Table_HDF5_Def<-cbind(Table_HDF5,Time_Rescaled)
    
    colnames(Table_HDF5_Def)<-c("Read", "Channel Number", "Mux Number", "Unix Time", "Length of Read", "Quality", "Relative Experimental Time")
    
    
    Relative_Time<-as.numeric(Table_HDF5_Def[,7])
    Relative_Time_Per_Hours<-seq(from=min(round(Relative_Time)), to=max(round(Relative_Time)), by=0.5)
    Template_Length<-as.numeric(Table_HDF5_Def[,5])
    Quality_Score<-as.numeric(Table_HDF5_Def[,6])
    
    
    message("Analyzing...")
    
    Reads_Per_Hour<-c()
    Base_Pairs_Per_Hour<-c()
    Max_Length_Per_Hour<-c()
    Mean_Length_Per_Hour<-c()
    Min_Length_Per_Hour<-c()
    Min_Quality_Score_Per_Hour<-c()
    Mean_Quality_Score_Per_Hour<-c()
    Max_Quality_Score_Per_Hour<-c()
    
    
    for (ii in 1:(length(Relative_Time_Per_Hours))) {
      
      if (ii < length(Relative_Time_Per_Hours)) {
        Index_Hours<-which(Relative_Time >= Relative_Time_Per_Hours[ii] & Relative_Time < Relative_Time_Per_Hours[ii+1])
        if (length(Index_Hours) == 0) {
          Reads_Per_Hour[ii]<-0
          Base_Pairs_Per_Hour[ii]<-0
          Mean_Length_Per_Hour[ii]<-0
          Max_Length_Per_Hour[ii]<-0
          Min_Length_Per_Hour[ii]<-0
          Mean_Quality_Score_Per_Hour[ii]<-0
          Min_Quality_Score_Per_Hour[ii]<-0
          Max_Quality_Score_Per_Hour[ii]<-0 
        }
        else
        {
          Reads_Per_Hour[ii]<-length(Index_Hours)
          Base_Pairs_Per_Hour[ii]<-sum(Template_Length[Index_Hours])
          Mean_Length_Per_Hour[ii]<-mean(Template_Length[Index_Hours])
          Max_Length_Per_Hour[ii]<-max(Template_Length[Index_Hours])
          Min_Length_Per_Hour[ii]<-min(Template_Length[Index_Hours])
          Mean_Quality_Score_Per_Hour[ii]<-mean(Quality_Score[Index_Hours])
          Min_Quality_Score_Per_Hour[ii]<-min(Quality_Score[Index_Hours])
          Max_Quality_Score_Per_Hour[ii]<-max(Quality_Score[Index_Hours])
        }
      }
      else {
        Index_Hours<-which(Relative_Time == Relative_Time_Per_Hours[ii])
        
        if (length(Index_Hours) == 0) {
          Reads_Per_Hour[ii]<-0
          Base_Pairs_Per_Hour[ii]<-0
          Mean_Length_Per_Hour[ii]<-0
          Max_Length_Per_Hour[ii]<-0
          Min_Length_Per_Hour[ii]<-0
          Mean_Quality_Score_Per_Hour[ii]<-0
          Min_Quality_Score_Per_Hour[ii]<-0
          Max_Quality_Score_Per_Hour[ii]<-0   
        }
        else {
          Reads_Per_Hour[ii]<-length(Index_Hours)
          Base_Pairs_Per_Hour[ii]<-sum(Template_Length[Index_Hours])
          Mean_Length_Per_Hour[ii]<-mean(Template_Length[Index_Hours])
          Max_Length_Per_Hour[ii]<-max(Template_Length[Index_Hours])
          Min_Length_Per_Hour[ii]<-min(Template_Length[Index_Hours])
          Mean_Quality_Score_Per_Hour[ii]<-mean(Quality_Score[Index_Hours])
          Min_Quality_Score_Per_Hour[ii]<-min(Quality_Score[Index_Hours])
          Max_Quality_Score_Per_Hour[ii]<-max(Quality_Score[Index_Hours])
        }
      }
    }
    
    
    Cumulative_Reads<-cumsum(Reads_Per_Hour)
    Cumulative_Basepairs<-cumsum(Base_Pairs_Per_Hour)
    
    Channel_Vector<-as.numeric(Table_HDF5_Def[,2])
    Mux_Vector<-as.numeric(Table_HDF5_Def[,3])
    Channels_Number<-c(1:512)
    
    
    Base_Pairs_Per_Channel<-c()
    
    Table_HDF5_Reordered<-c()
    
    for (iii in 1:length(Channels_Number)) {
      Ind_Chann<-which(Channel_Vector == Channels_Number[iii])
      Mux_Associated<-sort(Mux_Vector[Ind_Chann], index.return=TRUE)$ix
      if (length(Ind_Chann) == 0) {
        next
      }
      else {
        Table_HDF5_Re<-Table_HDF5_Def[Ind_Chann,][Mux_Associated,]
        Table_HDF5_Reordered<-rbind(Table_HDF5_Reordered,Table_HDF5_Re)
      }
      Base_Pairs_Per_Channel[iii]<-sum(Template_Length[Ind_Chann])
    }
    
    rownames(Table_HDF5_Reordered)<-c()
    
    
    #PLOT CUMULATIVE READS/BP
    
    
    message("Plotting...")
    
    x<-Relative_Time_Per_Hours
    y0.1<-Cumulative_Reads
    data0.1<-data.frame('x'=x,'y'=y0.1)
    data0.1$group<-"Cumulative Reads"
    
    
    Cumulative_Reads_Plot<-ggplot(data0.1, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Number Of Reads")+
      geom_ribbon(data=subset(data0.1,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
      scale_fill_manual(name='', values=c("Cumulative Reads" = "coral3"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12,face="italic"),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Cumulative Reads")
    
    y0.2<-Cumulative_Basepairs
    data0.2<-data.frame('x'=x,'y'=y0.2)
    data0.2$group<-"Cumulative Base Pairs"
    
    Cumulative_Base_Pairs_Plot<-ggplot(data0.2, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Number Of Base Pairs")+
      geom_ribbon(data=subset(data0.2,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
      scale_fill_manual(name='', values=c("Cumulative Base Pairs" = "darkcyan"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12,face="italic"),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Cumulative Base Pairs")
    
    Cumulative_Plot<-arrangeGrob(grid.arrange(Cumulative_Reads_Plot,Cumulative_Base_Pairs_Plot, nrow=2, ncol=1))
    
    ggsave(paste0(Label,"_",label,"_Cumulative_Reads_&_Cumulative_Basepairs.pdf"), device="pdf", Cumulative_Plot, height=10,width=15)
    
    #PLOT PER-HOUR READS/BPs/QUALITY/LENGTH
    
    
    y1<-Reads_Per_Hour
    data1<-data.frame('x'=x,'y'=y1)
    data1$group<-"Reads Per Hour"
    
    Reads_Per_Hour_Plot<-ggplot(data1, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Number Of Reads")+
      geom_ribbon(data=subset(data1,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
      scale_fill_manual(name='', values=c("Reads Per Hour" = "coral3"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Number Of Reads")
    
    
    y2<-Base_Pairs_Per_Hour
    data2<-data.frame('x'=x,'y'=y2)
    data2$group<-"Base Pairs Per Hour"
    
    
    Base_Pairs_Per_Hour_Plot<-ggplot(data2, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Number Of Base Pairs")+
      geom_ribbon(data=subset(data2,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,show.legend=FALSE) +
      scale_fill_manual(name='', values=c("Base Pairs Per Hour" = "darkcyan"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Number Of Base Pairs")
    
    
    y3.0<-log10(Mean_Length_Per_Hour)
    data3.0.0<-data.frame('x'=x,'y'=Mean_Length_Per_Hour)
    data3.0<-data.frame('x'=x,'y'=y3.0)
    data3.0$group<-"Mean Length"
    
    y3.1<-log10(Max_Length_Per_Hour)
    data3.1<-data.frame('x'=x,'y'=y3.1)
    data3.1$group<-"Max Length"
    
    y3.2<-log10(Min_Length_Per_Hour)
    data3.2<-data.frame('x'=x,'y'=y3.2)
    data3.2$group<-"Min Length"
    
    data3<-rbind(data3.0, data3.1, data3.2)
    
    Length_Per_Hour_Plot<-ggplot(data3, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Length", breaks=c(2,3,4,5,6), labels=c("100","1000","10000","100000","1000000"))+
      geom_ribbon(data=subset(data3,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0, alpha=.7) +
      scale_fill_manual(name='', values=c("Mean Length" = "darkolivegreen1", "Min Length" = "darkolivegreen", "Max Length" = "cornsilk"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Length")
    
    y4.0<-Mean_Quality_Score_Per_Hour
    data4.0<-data.frame('x'=x,'y'=y4.0)
    data4.0$group<-"Mean Quality"
    
    y4.1<-Min_Quality_Score_Per_Hour
    data4.1<-data.frame('x'=x,'y'=y4.1)
    data4.1$group<-"Min Quality"
    
    y4.2<-Max_Quality_Score_Per_Hour
    data4.2<-data.frame('x'=x,'y'=y4.2)
    data4.2$group<-"Max Quality"
    
    data4<-rbind(data4.0,data4.1,data4.2)
    
    Quality_Score_Per_Hour_Plot<-ggplot(data4, aes(x=x, y=y, group=group, fill=group)) +
      geom_line(size=.5) + 
      scale_x_continuous(name="Experimental Time", breaks=(seq(0,Run_Duration,2)))+
      scale_y_continuous(name="Quality")+
      geom_ribbon(data=subset(data4,x>=0 & x<=Run_Duration),aes(x=x,ymax=y),ymin=0,alpha=.7) +
      scale_fill_manual(name='', values=c("Mean Quality" = "chocolate1", "Min Quality" = "chocolate", "Max Quality" = "cornsilk"))+
      theme_bw(base_size = 12)+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.background = (element_rect(size=0.5, linetype="solid",colour ="black")), legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=12),axis.title.x = element_text(size=11, face="italic"),axis.title.y = element_text(size=11, face="italic"))+
      theme(legend.position="bottom")+
      ggtitle("Quality Score")
    
    
    Others_Plot<-arrangeGrob(grid.arrange(Reads_Per_Hour_Plot,Base_Pairs_Per_Hour_Plot,Length_Per_Hour_Plot,Quality_Score_Per_Hour_Plot, nrow=2, ncol=2))
    
    ggsave(paste0(Label,"_",label,"_Reads_Basepairs_Length_Quality.pdf"), device="pdf", Others_Plot, height=10,width=15)
    
    #PASS/FAIL
    
    blank_theme <- theme_minimal()+
      theme(
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.border = element_blank(),
        panel.grid=element_blank(),
        axis.ticks = element_blank(),
        plot.title=element_text(size=14, face="bold"),
        axis.text.x=element_blank()
      )
    
    Data_Pass_Fail_Percentage <- data.frame(
      group = c("Pass", "Fail/Skip"),
      value = c((List.Files.HDF5_Pass.length/(List.Files.HDF5_Pass.length+List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length)), ((List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length)/(List.Files.HDF5_Pass.length+List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length)))
    )
    
    
    Data_Pass_Fail_Percentage_Plot<-ggplot(Data_Pass_Fail_Percentage, aes(x="", y=value, fill=group))+
      geom_bar(width = 1, size = 1, color = "white", stat = "identity")+
      geom_text(aes(label = scales::percent(value)), position = position_stack(vjust = 0.5))+
      coord_polar("y", start=0) +
      scale_fill_brewer(palette="Dark2") +
      blank_theme+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.title=element_blank(),legend.position="bottom")+
      ggtitle("Passed and Failed/Skipped Percentage")
    
    
    Data_Pass_Fail_Tot <- data.frame(
      group = c("Pass", "Fail/Skip"),
      value = c(List.Files.HDF5_Pass.length, (List.Files.HDF5_Fail_Length+List.Files.HDF5_Skip_Length))
    )
    
    Data_Pass_Fail_Tot_Plot<-ggplot(Data_Pass_Fail_Tot, aes(x="", y=value, fill=group))+
      geom_bar(width = 1, size = 1, color = "white", stat = "identity")+
      geom_text(aes(label = value), position = position_stack(vjust = 0.5))+
      coord_polar("y", start=0) +
      scale_fill_brewer(palette="Accent") +
      blank_theme+
      theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=14),legend.title=element_blank(), legend.position="bottom")+
      ggtitle("Passed and Failed/Skipped Number")
    
    #WILL BE SAVED WITH GC CONTENT
    
    
    ###################### LENGTH_VS_QUALITY ######################
    
    Tot_Length<-data.frame(Template_Length)
    Tot_Quality<-data.frame(Quality_Score)
    
    
    ScatterTheme <- list(labs(x="Length",y="Quality"),theme_bw(), theme(legend.position=c(1,0),legend.justification=c(1,0), legend.background=element_blank(),legend.direction="horizontal", legend.title=element_text(face="bold.italic"),axis.title=element_text(face="italic")))
    
    
    hist_top_mean_length<-ggplot(Tot_Length, aes(x=Template_Length))+theme_bw()+ geom_histogram(aes(y = ..count../1000),col="darkolivegreen", fill="darkolivegreen1",boundary = min(Tot_Length$Template_Length))+labs(x="",y="Count (x 1e3)")+scale_x_continuous(limits=c(min(Tot_Length$Template_Length),max(Tot_Length$Template_Length)))+theme(axis.title=element_text(face="italic"))
    hist_right_mean_quality<-ggplot(Tot_Quality, aes(x=Quality_Score))+ theme_bw()+ geom_histogram(aes(y = ..count../1000),col="chocolate", fill="chocolate1",boundary = min(Tot_Quality$Quality_Score))+ labs(x="",y="Count (x 1e3)")+coord_flip()+scale_x_continuous(limits=c(min(Tot_Quality$Quality_Score),max(Tot_Quality$Quality_Score)))+theme(axis.title=element_text(face="italic"))
    empty <- ggplot()+geom_point(aes(1,1), colour="white")+
      theme(axis.ticks=element_blank(), 
            panel.background=element_blank(), 
            axis.text.x=element_blank(), axis.text.y=element_blank(),           
            axis.title.x=element_blank(), axis.title.y=element_blank())
    scatter <- ggplot(data.frame(cbind(Tot_Length$Template_Length,Tot_Quality$Quality_Score)),aes(x=Tot_Length$Template_Length, y=Tot_Quality$Quality_Score))+geom_point(col="grey27", size=.09, alpha=.4)+scale_x_continuous(limits=c(min(Tot_Length$Template_Length),max(Tot_Length$Template_Length)))+scale_y_continuous(limits=c(min(Tot_Quality$Quality_Score),max(Tot_Quality$Quality_Score)))+stat_density2d(aes(col=..level.., alpha=..level..)) + scale_color_continuous(low="darkblue",high="darkred") +geom_smooth(method=lm,linetype=2, size=.5,col="black",se=F) + guides(alpha="none",col=guide_legend(title="Density"))+ ScatterTheme
    
    
    
    
    Length_VS_Quality_Plot<-grid.arrange(hist_top_mean_length, empty, scatter, hist_right_mean_quality, ncol=2, nrow=2, widths=c(4,1), heights=c(1, 4))
    
    
    ggsave(paste0(Label,"_",label,"_Length_versus_Quality.pdf"), device="pdf", Length_VS_Quality_Plot, height=10,width=15)
    
    
    # MUX PRODUCTIVITY PER CHANNEL
    
    Mux_Numbers<-c(1:4)
    
    Chan<-as.numeric(Table_HDF5_Reordered[,2])
    Mu<-as.numeric(Table_HDF5_Reordered[,3])
    Le<-as.numeric(Table_HDF5_Reordered[,5])
    
    List_Of_Mux<-list()
    
    for (iii in 1:length(Channels_Number)) {
      Ind_Chann<-which(Chan == Channels_Number[iii])
      Mux_Associated_Number<-sort(Mu[Ind_Chann])
      Table_Mux<-c()
      for (lll in 1:length(Mux_Numbers)) {
        Ind_Mux<-which(Mux_Associated_Number == Mux_Numbers[lll])
        Chan_Mux<-Chan[Ind_Chann][Ind_Mux]
        if (length(Chan_Mux) == 0) {
          Mux<-NA
          Lenght_Per_Mux<-NA
          Table_Mu<-cbind(NA, NA, NA)
          Table_Mux<-rbind(Table_Mux,Table_Mu)
        }
        else {
          Mux<-Mu[Ind_Chann][Ind_Mux]
          Lenght_Per_Mux<-sum(Le[Ind_Chann][Ind_Mux])
          Table_Mu<-cbind(unique(Chan_Mux), unique(Mux),Lenght_Per_Mux)
          Table_Mux<-rbind(Table_Mux,Table_Mu)
        }
      }
      List_Of_Mux[[iii]]<-Table_Mux
    }
    
    Table_Mux_Def<-do.call(rbind,List_Of_Mux)
    
    
    colnames(Table_Mux_Def)<-c("Channel Number", "Mux Number", "Total Reads Produced Per Mux")
    
    #PLOT CORRELATION MATRIXES (CHANNEL AND MUXES)
    
    m1<-matrix(Base_Pairs_Per_Channel[1:32], ncol=8, nrow=4, byrow=TRUE)
    m2<-matrix(Base_Pairs_Per_Channel[449:480], ncol=8, nrow=4, byrow=TRUE)
    m3<-matrix(Base_Pairs_Per_Channel[385:416], ncol=8, nrow=4, byrow=TRUE)
    m4<-matrix(Base_Pairs_Per_Channel[321:352], ncol=8, nrow=4, byrow=TRUE)
    m5<-matrix(Base_Pairs_Per_Channel[257:288], ncol=8, nrow=4, byrow=TRUE)
    m6<-matrix(Base_Pairs_Per_Channel[193:224], ncol=8, nrow=4, byrow=TRUE)
    m7<-matrix(Base_Pairs_Per_Channel[129:160], ncol=8, nrow=4, byrow=TRUE)
    m8<-matrix(Base_Pairs_Per_Channel[65:96], ncol=8, nrow=4, byrow=TRUE)
    mdef3<-rbind(m1,m2,m3,m4,m5,m6,m7,m8)
    m9<-rotate(matrix(Base_Pairs_Per_Channel[33:64], ncol=8, nrow=4, byrow=TRUE))
    m10<-rotate(matrix(Base_Pairs_Per_Channel[481:512], ncol=8, nrow=4, byrow=TRUE))
    m11<-rotate(matrix(Base_Pairs_Per_Channel[417:448], ncol=8, nrow=4, byrow=TRUE))
    m12<-rotate(matrix(Base_Pairs_Per_Channel[353:384], ncol=8, nrow=4, byrow=TRUE))
    m13<-rotate(matrix(Base_Pairs_Per_Channel[289:320], ncol=8, nrow=4, byrow=TRUE))
    m14<-rotate(matrix(Base_Pairs_Per_Channel[225:256], ncol=8, nrow=4, byrow=TRUE))
    m15<-rotate(matrix(Base_Pairs_Per_Channel[161:192], ncol=8, nrow=4, byrow=TRUE))
    m16<-rotate(matrix(Base_Pairs_Per_Channel[97:128], ncol=8, nrow=4, byrow=TRUE))
    mdef4<-rbind(m9,m10,m11,m12,m13,m14,m15,m16)
    Matrixbpchannel<-cbind(mdef3,mdef4)
    
    BasePairs_Per_Mux<-as.numeric(Table_Mux_Def[,3])
    
    First_Eight_Disposition<-c(3,4,1,2,6,5,8,7)
    Second_Eight_Disposition<-Increment(First_Eight_Disposition)
    Third_Eight_Disposition<-Increment(Second_Eight_Disposition)
    Fouth_Eight_Disposition<-Increment(Third_Eight_Disposition)
    First_Line<-c(First_Eight_Disposition,Second_Eight_Disposition,Third_Eight_Disposition,Fouth_Eight_Disposition)
    Second_Line<-Increment2(First_Line)
    Third_Line<-Increment2(Second_Line)
    Fourth_Line<-Increment2(Third_Line)
    First_Block<-c(First_Line,Second_Line,Third_Line,Fourth_Line)
    Second_Block<-Increment3(First_Block)
    Third_Block<-Increment3(Second_Block)
    Fourth_Block<-Increment3(Third_Block)
    Fifth_Block<-Increment3(Fourth_Block)
    Sixth_Block<-Increment3(Fifth_Block)
    Seventh_Block<-Increment3(Sixth_Block)
    Eight_Block<-Increment3(Seventh_Block)
    Ninth_Block<-Increment3(Eight_Block)
    Tenth_Block<-Increment3(Ninth_Block)
    Eleventh_Block<-Increment3(Tenth_Block)
    Twelfth_Block<-Increment3(Eleventh_Block)
    Thirtheenth_Block<-Increment3(Twelfth_Block)
    Fourtheenth_Block<-Increment3(Thirtheenth_Block)
    Fiftheenth_Block<-Increment3(Fourtheenth_Block)
    Sixtheenth_Block<-Increment3(Fiftheenth_Block)
    
    M1<-matrix(BasePairs_Per_Mux[First_Block], ncol= 32, nrow= 4, byrow=TRUE)
    M2<-matrix(BasePairs_Per_Mux[Fiftheenth_Block], ncol= 32, nrow= 4, byrow=TRUE)
    M3<-matrix(BasePairs_Per_Mux[Thirtheenth_Block], ncol= 32, nrow= 4, byrow=TRUE)
    M4<-matrix(BasePairs_Per_Mux[Eleventh_Block], ncol= 32, nrow= 4, byrow=TRUE)
    M5<-matrix(BasePairs_Per_Mux[Ninth_Block], ncol= 32, nrow= 4, byrow=TRUE)
    M6<-matrix(BasePairs_Per_Mux[Seventh_Block], ncol= 32, nrow= 4, byrow=TRUE)
    M7<-matrix(BasePairs_Per_Mux[Fifth_Block], ncol= 32, nrow= 4, byrow=TRUE)
    M8<-matrix(BasePairs_Per_Mux[Third_Block], ncol= 32, nrow= 4, byrow=TRUE)
    Mdef3<-rbind(M1,M2,M3,M4,M5,M6,M7,M8)
    M9<-rotate(matrix(BasePairs_Per_Mux[Second_Block], ncol= 32, nrow= 4, byrow=TRUE))
    M10<-rotate(matrix(BasePairs_Per_Mux[Sixtheenth_Block],ncol= 32, nrow= 4, byrow=TRUE))
    M11<-rotate(matrix(BasePairs_Per_Mux[Fourtheenth_Block], ncol= 32, nrow= 4, byrow=TRUE))
    M12<-rotate(matrix(BasePairs_Per_Mux[Twelfth_Block], ncol= 32, nrow= 4, byrow=TRUE))
    M13<-rotate(matrix(BasePairs_Per_Mux[Tenth_Block], ncol= 32, nrow= 4, byrow=TRUE))
    M14<-rotate(matrix(BasePairs_Per_Mux[Eight_Block], ncol= 32, nrow= 4, byrow=TRUE))
    M15<-rotate(matrix(BasePairs_Per_Mux[Sixth_Block], ncol= 32, nrow= 4, byrow=TRUE))
    M16<-rotate(matrix(BasePairs_Per_Mux[Fourth_Block], ncol= 32, nrow= 4, byrow=TRUE))
    Mdef4<-rbind(M9,M10,M11,M12,M13,M14,M15,M16)
    MatrixMuxActivity<-cbind(Mdef3,Mdef4)
    
    
    #PLOTTING "FALSE" CORRELATION MATRIXES
    
    Palette <- colorRampPalette(brewer.pal(9, "Reds"))
    
    adjMatrixbpchannel<-melt(rotate(t(Matrixbpchannel)))
    Plot_Channel_Activity<-ggplot(data=adjMatrixbpchannel, aes(x=Var1, y=Var2)) +
      geom_tile(aes(fill=value), color="white", size=2)+
      scale_fill_gradientn(colours= Palette(4), na.value="grey70",limits=c(min(adjMatrixbpchannel[,3], na.rm=TRUE), max(adjMatrixbpchannel[,3], na.rm=TRUE))) +
      theme(axis.line=element_blank(),axis.text.x=element_blank(),
            axis.text.y=element_blank(),axis.ticks=element_blank(),
            axis.title.x=element_blank(),
            axis.title.y=element_blank(),legend.position="bottom",
            legend.title=element_text(face="bold.italic"),
            panel.background=element_blank(),panel.border=element_blank(),panel.grid.major=element_blank(),
            panel.grid.minor=element_blank(),plot.background=element_blank(),legend.text=element_text(size=10),
            plot.title = element_text(hjust = 0.5,face="bold.italic",size=16),legend.text.align = 0)+
      guides(fill = guide_colorbar(barwidth= 61,barheight=.5,title="Base Pairs Productivity", title.position="top",title.hjust=0.5))+
      ggtitle("Channels Activity")
    
    adjMatrixMuxActivity<-melt(rotate(t(MatrixMuxActivity)))
    Plot_Mux_Activity<-ggplot(data=adjMatrixMuxActivity, aes(x=Var1, y=Var2)) +
      geom_tile(aes(fill=value), color="white", size=2)+
      scale_fill_gradientn(colours=Palette(4), na.value="grey70",limits=c(min(adjMatrixMuxActivity[,3], na.rm=TRUE), max(adjMatrixMuxActivity[,3], na.rm=TRUE))) +
      theme(axis.line=element_blank(),axis.text.x=element_blank(),
            axis.text.y=element_blank(),axis.ticks=element_blank(),
            axis.title.x=element_blank(),
            axis.title.y=element_blank(),legend.position="bottom",
            legend.title=element_text(face="bold.italic"),
            panel.background=element_blank(),panel.border=element_blank(),panel.grid.major=element_blank(),
            panel.grid.minor=element_blank(),plot.background=element_blank(),legend.text=element_text(size=10),
            plot.title = element_text(hjust = 0.5,face="bold.italic",size=16))+
      guides(fill = guide_colorbar(barwidth= 61, barheight=.5,title="Base Pairs Productivity", title.position="top",title.hjust=0.5))+
      ggtitle("Muxes Activity")
    
    
    Plot_Tot<-grid.arrange(arrangeGrob(Plot_Channel_Activity,Plot_Mux_Activity,nrow=2, ncol=1, widths=15, heights=c(12,12)))
    
    ggsave(paste0(Label,"_",label,"_Channels_and_Muxes_Activity.pdf"), device="pdf",Plot_Tot, height=10, width=18)
    
    
    ###PLOT GC CONTENT#######
    
    if (NanoGTable[1,7] == "GC_Content") {
      
      pdf(paste0(Label,"_",label,"_Pass_Fail_Skip_NO_GC_Content.pdf"), height=10, width=15, onefile=TRUE)
      grid.newpage()
      pushViewport(viewport(layout = grid.layout(1, 2)))
      print(Data_Pass_Fail_Percentage_Plot, vp=define_region(1, 1))
      print(Data_Pass_Fail_Tot_Plot, vp = define_region(1, 2))
      dev.off()
    }
    
    else {
      
      GC_Content_To_Plot<-as.numeric(NanoTable[,7])
      Hist_GC_Content<-ggplot(data.frame(GC_Content_To_Plot), aes(x=GC_Content_To_Plot))+theme_bw()+ geom_histogram(col="midnightblue", fill="cyan4")+labs(x="",y="Count")+ggtitle("GC Content")+theme(plot.title = element_text(hjust = 0.5,face="bold.italic",size=16), axis.title.y=element_text(face="italic"))
      pdf(paste0(Label,"_",label,"_Pass_Fail_Skip_and_GC_Content.pdf"), height=10, width=15, onefile=TRUE)
      grid.newpage()
      pushViewport(viewport(layout = grid.layout(2, 2)))
      print(Data_Pass_Fail_Percentage_Plot, vp=define_region(1, 1))
      print(Data_Pass_Fail_Tot_Plot, vp = define_region(1, 2))
      print(Hist_GC_Content, vp = define_region(2, 1:2))
      dev.off()
    }
    
    #save data for other analyses
    
    write.table(data1, file.path(Directory, paste0(Label,"_",label, "_ReadsProduced.txt")),col.names=T, sep="\t")
    write.table(data2, file.path(Directory, paste0(Label,"_",label, "_BasePairsProduced.txt")),col.names=T, sep="\t")
    write.table(data3.0.0, file.path(Directory, paste0(Label,"_",label, "_MeanLength.txt")),col.names=T, sep="\t")
    write.table(data4.0, file.path(Directory, paste0(Label,"_",label, "_MeanQuality.txt")),col.names=T, sep="\t")
    
    message("Done!")
    
  }
  
}


#### FASTQFILTERG ####

#' @title Filter .fastq files outputted by GridION X5
#' @description Use this function if you have .fastq and sequencing summary files and you want to filter your .fastq files in order to obtain only the passed ones. In addition, you can ask to FastqFilterG to return the total .fastq file, the total .fasta file and the .fasta file for high-quality sequences. 
#' @param Data Path to .fastq and sequencing summary files returned from GridION X5 (can find .fastq and sequencing summary files recursively)
#' @param DataOut Where the .fastq file for reas with quality greater (or equal) to 7 will be saved (and, if you wish the .fasta file for high-quality reads, the total .fastq file and the .fasta file) will be saved
#' @param FASTQTOT Logical; do you want to produce a .fa stq file that is the result of the concatenation of all .fastq files returned by GridION X5?
#' @param FASTA Logical; do you want to produce a pass .fasta file and, if FASTQTOT = TRUE, a total .fasta file?
#' @param Cores Number of cores to use to accelerate sequencing summary files reading
#' @param Label A label that will be used, together with the Flow Cell identifier extracted from the inputted data, to identify the experiment
#' @return By default, .fastq file of reads with quality greater (or equal) than 7. As FastqFilterG reads each .fastq file when creating its output, if one .fastq file is "ill-formatted", FastqFilterG will stop and print the number of the "guilty" .fastq file.
#' @examples
#' #do not run
#' DataPath<-"/data/basecalled/ExperimentName/FlowCellId"
#' FastqFilterG(Data=DataPath, DataOut="Path/To/DataOut",FASTQTOT=FALSE,FASTA=FALSE) #avoid re-running on errors: ill-formatted .fastq files are found sometimes.


FastqFilterG<-function(Data,DataOut,FASTQTOT=FALSE,FASTA=FALSE,Cores=1,Label) {
  
  library(ShortRead)

  Label<-as.character(Label)
  


  FastqFiles<-list.files(Data,pattern=".fastq",full.names=TRUE, recursive=TRUE)
  FastqFilesPathOrdered<-FastqFiles[order(as.numeric(gsub("[^0-9]+", "", FastqFiles)))]
  
  
  SummariesFiles<-list.files(Data,full.names=TRUE,pattern="sequencing_summary", recursive=TRUE)
  SummariesFilesOrdered<-SummariesFiles[order(as.numeric(gsub("[^0-9]+", "", SummariesFiles)))]
  
  Minimal_Read_Table_Summary<-function(i,File) {
    Table<-read.table(File[i],header=FALSE,sep="\t",skip=1)
    Flowcell_ID_Label<-unlist(strsplit(as.character(Table[,1]),"_"))[4]
    Flowcell_ID<-rep(Flowcell_ID_Label,dim(Table)[1])
    Read_Id<-as.character(Table[,2])
    Qscore<-as.numeric(Table[,12])
    Table<-cbind(Flowcell_ID,Read_Id,Qscore)
    return(Table)
  }
  
  
  cl <- makeCluster(as.numeric(Cores)) 
  clusterExport(cl, c("Minimal_Read_Table_Summary","SummariesFilesOrdered"),envir=environment())
  List<-parLapply(cl, c(1:length(SummariesFilesOrdered)),Minimal_Read_Table_Summary,SummariesFilesOrdered)
  stopCluster(cl)
  
  SummaryTable<-do.call(rbind,List)
  
  Directory<-file.path(DataOut)
  dir.create(Directory, showWarnings=FALSE)
  
  
  TablePass<-which(as.numeric(SummaryTable[,3]) >= 7)
  PassTable<-Table[TablePass,]
  IdPass<-as.character(PassTable[,2])
  Flowcell_ID_Label<-as.character(Table[1,1])
  if (Flowcell_ID_Label == "GA10000") {
    Flowcell_ID_Label<-as.character("FC1")
  }
  if (Flowcell_ID_Label == "GA20000") {
    Flowcell_ID_Label<-as.character("FC2")
  }
  if (Flowcell_ID_Label == "GA30000") {
    Flowcell_ID_Label<-as.character("FC3")
  }
  if (Flowcell_ID_Label == "GA40000") {
    Flowcell_ID_Label<-as.character("FC4")
  }
  if (Flowcell_ID_Label == "GA50000") {
    Flowcell_ID_Label<-as.character("FC5")
  }
  
  message("Starting .fastq files analysis...")
  
  for(i in 1:length(FastqFilesPathOrdered)) {
    
    fqFile<-FastqFile(FastqFilesPathOrdered[i])
    BuildTotalFastq<-tryCatch({
      readFastq(fqFile)},
      error = function(cond) {
        return(NULL)},
      warning = function(cond) {
        message(cond)
        return(NULL)}
    )
    if (is.null(BuildTotalFastq)) {
      stop(paste0("Ill-formatted .fastq file at fastq ",i, "! Can't write .fastq information. This error occurs when a .fastq file is not formatted correctly."))
    }
    else {
      if (FASTQTOT == TRUE) {
        if (i == 1) {
          message("Start writing total .fastq file...")
        }
        writeFastq(BuildTotalFastq, file.path(Directory,paste0(Label,"_",Flowcell_ID_Label,"_FastqTot.fastq")), mode="a", compress=FALSE)
        if (FASTA == TRUE) {
          if (i == 1) {
            
            message("Start writing total .fasta file...")
          }  
          
          writeFasta(BuildTotalFastq,file.path(Directory,paste0(Label,"_",Flowcell_ID_Label,"_FastaTot.fastq")), mode="a", compress=FALSE)
        }
      }
      Id<-id(BuildTotalFastq)
      CharId<-as.character(Id)
      NewReadsSplitted<-unlist(strsplit(CharId," "))
      IdNames<-NewReadsSplitted[seq(1,length(NewReadsSplitted),8)]
      close(fqFile)
      Matches<-match(IdNames,IdPass,nomatch=-10)
      MatchesNew<-which(Matches != -10)
      ReadsPassed<-BuildTotalFastq[MatchesNew]
      if (i == 1){
        message("Start writing high-quality .fastq file...")
      }
      writeFastq(ReadsPassed,file=file.path(Directory, paste0(Label,"_",Flowcell_ID_Label,"_PassFastq.fastq")),compress=FALSE,mode="a")
      if (FASTA==TRUE) {
        if (i == 1) {
          message("Start writing high-quality .fasta file...")
        }
        writeFasta(ReadsPassed,file=file.path(Directory, paste0(Label,"_",Flowcell_ID_Label,"_PassFasta.fasta")),compress=FALSE,mode="a")
      }
    }
  }
  message("Done!")
}


############################################ NanoFastqG ############################################

#' @title Extracts .fastq informations from your GridION X5  basecalled "Pass" .fast5 files
#' @description NanoFastqG returns a file text containing .fastq sequences (and, if you want, an additional file text containing .fasta sequences) extracted from your "Pass" .fast5 reads.
#' @param DataPass Path to "Pass" .fast5 files folder (can find .fast5 files recursively)
#' @param DataOut Where your .fastq (and .fasta) file will be saved
#' @param Label A lable used to identify .fastq (and .fasta) file outputted
#' @param Cores Number of cores to be used: 1 by default
#' @param FASTA Logical. If FALSE (by default), return only .fastq file else, if TRUE, return both .fastq and .fasta files
#' @return .fastq file and, if you wish, .fasta file for your "Pass" .fast5 files.
#' @examples
#' #do not run
#' NanoFastqG(DataPass="Path/To/DataPass", DataOut="/Path/To/DataOutExp", Cores=6, FASTA=FALSE)
#' NanoFastqG(DataPass="Path/To/DataPass", DataOut="/Path/To/DataOutExp", Cores=6, FASTA=TRUE)


NanoFastqG<-function(DataPass,DataOut,Label,Cores=1,FASTA=FALSE) {
  
  library(rhdf5)
  library(parallel)
  library(ShortRead)
  
  Directory<-file.path(DataOut)
  dir.create(Directory,showWarnings=FALSE)
  setwd(Directory)
  
  label<-as.character(Label)
  PassFiles<-list.files(DataPass, full.names=TRUE, recursive = TRUE, pattern=".fast5")
  
  
  ### FUNCTIONS ###
 
  Read_DataSet<-function(File, PathGroup) { 
    h5errorHandling(type="suppress")
    Data1<-H5Dopen(File, PathGroup) 
    Data2<-H5Dread(Data1)
    H5Dclose(Data1)
    return(Data2) 
  }
  
  Read_Attributes<-function(PathGroup, Attribute) { 
    h5errorHandling(type="suppress")

    Data1<-H5Aopen(PathGroup, Attribute)
    Data2<-H5Aread(Data1)
    H5Aclose(Data1)
    return(Data2) 
  } 
  
  Fastq_Extraction<-function(i,File) {
    
    
    Fastq<-list()
    
    h5errorHandling(type="suppress")
    File<-H5Fopen(File[i])
    
    GroupTry<-"/Analyses/Basecall_1D_000/BaseCalled_template/Fastq"
    
    Try<-try(Read_DataSet(File,GroupTry), silent=TRUE) #exclude not-basecalled .fast5 files
    
    if (inherits(Try,"try-error")) {
      H5Fclose(File)
      Fastq[[i]]<-NA
      return(Fastq[[i]])
    }
    
    else {
      
      Group0<-"/Analyses/Basecall_1D_000/Summary/basecall_1d_template"
      Score<-H5Gopen(File,Group0)
      Quality<-Read_Attributes(Score,"mean_qscore")
      H5Gclose(Score)
      
      if (Quality >= 7) { 
        Pre_Fastq<-Read_DataSet(File,GroupTry)
        Fastq[[i]]<- strsplit(Pre_Fastq,split="\n",fixed=TRUE)[[1]]
      }
      
      else
      {
        Fastq[[i]]<-NA
      }
      H5Fclose(File)
      return(Fastq[[i]])
    }
  }

  ###### EXTRACT GRIDION LABEL #####
  
  FileOpen<-H5Fopen(PassFiles[1])
  Group4.2<-"/UniqueGlobalKey/tracking_id"
  Lab<-H5Gopen(FileOpen,Group4.2)
  Flowcell_ID_Label<-Read_Attributes(Lab, "device_id")
  H5Gclose(Lab)
  H5Fclose(FileOpen)

  if (Flowcell_ID_Label == "GA10000") {
    Flowcell_ID_Label<-as.character("FC1")
  }
  if (Flowcell_ID_Label == "GA20000") {
    Flowcell_ID_Label<-as.character("FC2")
  }
  if (Flowcell_ID_Label == "GA30000") {
    Flowcell_ID_Label<-as.character("FC3")
  }
  if (Flowcell_ID_Label == "GA40000") {
    Flowcell_ID_Label<-as.character("FC4")
  }
  if (Flowcell_ID_Label == "GA50000") {
    Flowcell_ID_Label<-as.character("FC5")
  }

  ################################
  
  
  if (FASTA == FALSE) {
    message("Starting .fastq sequences extraction!")
  }
  else {
    message("Starting .fastq sequences and .fasta sequences extraction!")
  }
  
  cl <- makeCluster(as.numeric(Cores)) 
  clusterExport(cl, c("Fastq_Extraction","PassFiles","Read_DataSet","Read_Attributes"),envir=environment())
  clusterEvalQ(cl,library(rhdf5))
  List<-parLapply(cl, c(1:length(PassFiles)),Fastq_Extraction,PassFiles)
  stopCluster(cl)
  FastqTot<-do.call(c,List)
  FastqClean<-which(is.na(FastqTot) == FALSE)
  FastqFinal<-(FastqTot[FastqClean])
  message("Writing .fastq file!")
  fileConn<-file(paste0(label,"_",Flowcell_ID_Label,".fastq"))
  writeLines(FastqFinal,fileConn)
  close(fileConn)

  if (FASTA == TRUE) {
    message("Writing .fasta file!")
    Fastq = FastqStreamer(file.path(Directory,paste0(label,"_",Flowcell_ID_Label,".fastq")))
    repeat {
      Fasta = yield(Fastq)
      if (length(Fasta) == 0) break
      writeFasta(Fasta, file=file.path(Directory,paste0(label,"_",Flowcell_ID_Label,".fasta")), mode="a")
    }
  }

  message("Done!") 
}



#### NANOCOMPARE ####


#' @title Plots comparison statistics for your MinION and GridION X5 experiments
#' @description NanoCompare returns plots of comparison between MinION/GridION X5 experiments previously analyzed with NanoTableM/NanoTableG and NanoStatsM/NanoStatsG functions.
#' @param DataIn One vector containing paths to folder in which there are ".txt" results returned from NanoTableM/NanoTableG and NanoStatsM/NanoStatG functions
#' @param DataOut Where your plots will be saved
#' @param Labels One vector containing ordered labels used for naming your MinION/GridIon experiments (for MinION experiments, the labels used in NanoPrepareM function, for GridION experiment, the labels used in NanoPrepareG function and the Flow Cell identifier, separated with an underscore character)
#' @param GCC Logical. Do all your information tables contain a numeric GC content count? 
#' @return Plots: \cr 
#' - Comparison of reads number, base pairs number, mean reads length and mean reads quality calculated every 10 hours of experiment (Comparison_Violins.pdf); \cr 
#' - Comparison of reads length, reads quality and reads GC content count (if GCC is set to TRUE) (Comparison_Histograms.pdf).
#' @examples
#' #do not run
#' DataIn<-c("/Path/To/DataOutExp1","/Path/To/DataOutExp2",...)
#' DataIn2<-c("/Path/To/DataOutExFC1","/Path/To/DataOutExFC2",...)
#' DataOut<-"Path/To/DataOutComparison"
#' Lab<-c("Exp1","Exp2",...)
#' Lab2<-c("Ex_FC1","Ex_FC2",...)
#' NanoCompare(DataIn=DataIn, DataOut=DataOut, Labels=Lab, GCC=TRUE)
#' NanoCompare(DataIn=DataIn2, DataOut=DataOut, Labels=Lab2, GCC=TRUE)


NanoCompare<-function(DataIn,DataOut,Labels,GCC=TRUE) {
  
  library(scales)
  library(ggplot2)
  library(RColorBrewer)
  library(grid)
  library(gridExtra)
  
  Directory<-file.path(DataOut)
  dir.create(Directory, showWarnings = FALSE)
  setwd(Directory)
  
  g_legend<-function(a.gplot)
  {
    tmp <- ggplot_gtable(ggplot_build(a.gplot))
    leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
    legend <- tmp$grobs[[leg]]
    return(legend)
  } 
  
  split.vars<-DataIn
  split.vars2<-Labels
  
  if (length(split.vars) != length(split.vars2)) {
    stop("There is no correspondence in number of folders and number of labels. For each experiment one label must be provided!")
  }
  
  Name_Of_Runs_To_Compare<-split.vars2
  
  Table_List<-list()
  Length_Data<-c()
  
  for (n in 1:length(split.vars)) {
    Data_Reads<-read.table(file.path(split.vars[n], paste0(Name_Of_Runs_To_Compare[n],"_ReadsProduced.txt")), header=T, sep="\t")
    Length_Data[n]<-length(Data_Reads[,1])
    Table_List[[n]]<-Data_Reads
  }
  
  Major_Index<-which.max(Length_Data)
  
  if (Length_Data[Major_Index] %% 10 != 0) {
    Group2<-c(rep(head(seq(min(Table_List[[Major_Index]]$x), max(Table_List[[Major_Index]]$x), 10), length(seq(min(Table_List[[Major_Index]]$x), max(Table_List[[Major_Index]]$x), 10))-1), each=20),rep(tail(seq(min(Table_List[[Major_Index]]$x), max(Table_List[[Major_Index]]$x), 10),1),2*(max(Table_List[[Major_Index]]$x)-tail(seq(min(Table_List[[Major_Index]]$x), max(Table_List[[Major_Index]]$x), 10),1))+1))
  }
  
  if (Length_Data[Major_Index] %% 10 == 0) {
    Group2<-c(rep(head(seq(min(Table_List[[Major_Index]]$x), max(Table_List[[Major_Index]]$x), 10), length(seq(min(Table_List[[Major_Index]]$x), max(Table_List[[Major_Index]]$x), 10))-1), each=20),max(Table_List[[Major_Index]]$x)) 
  }
  
  
  ##########
  New_Group_2<-c()
  
  for (i in 1:length(Group2)) {
    if (Group2[i] == 0) {
      New_Group_2[i]<-as.character("0-10 hours")
    }
    if (Group2[i] == 10) {
      New_Group_2[i]<-as.character("10-20 hours")
    }
    if (Group2[i] == 20) {
      New_Group_2[i]<-as.character("20-30 hours")
    }
    if (Group2[i] == 30) {
      New_Group_2[i]<-as.character("30-40 hours")
    }
    if (Group2[i] == 40) {
      New_Group_2[i]<-as.character("40-50 hours")
    }
    if (Group2[i] == 50) {
      New_Group_2[i]<-as.character("50-60 hours")
    }
  }
  
  ############VIOLINS COMPARISON#########
  
  List_Data_Reads<-list()
  List_Data_BasePairs<-list()
  List_Data_Length<-list()
  List_Data_Quality<-list()
  
  
  options(scipen=9999)


  message("Creating comparison violins...")
  
  for (nn in 1:length(split.vars)) {
    Data_Reads1<-Table_List[[nn]]
    if (length(Data_Reads1[,1]) != length(Group2)) {  
      x<-c(Data_Reads1$x,seq(max(Data_Reads1$x)+.5, max(Table_List[[Major_Index]]$x),0.5))
      y<-c(Data_Reads1$y, rep(0, length(seq(max(Data_Reads1$x)+.5, max(Table_List[[Major_Index]]$x),0.5))))
      group<-rep("Reads", length(y))
      value<-rep(Name_Of_Runs_To_Compare[nn], length(y))
      group2<-factor(as.character(New_Group_2), levels=c("0-10 hours","10-20 hours","20-30 hours","30-40 hours","40-50 hours"))
      Data_Reads1<-data.frame(x,y,group,value,group2)
    }
    else {    
      Data_Reads1$group<-"Reads"
      Data_Reads1$value<-Name_Of_Runs_To_Compare[nn]
      Data_Reads1$group2<-factor(as.character(New_Group_2), levels=c("0-10 hours","10-20 hours","20-30 hours","30-40 hours","40-50 hours"))
    }
    List_Data_Reads[[nn]]<-Data_Reads1
    if (length(List_Data_Reads) == length(split.vars)) {
      Reads_To_Plot<-do.call(rbind, List_Data_Reads)
      Violins_Reads<-ggplot(Reads_To_Plot, aes(x=group,y=y, fill=value)) + 
        geom_violin(draw_quantiles = c(0.25, 0.5, 0.75))+
        labs(x="", y = "Reads")+ 
        scale_fill_brewer(palette= "Set3") + 
        scale_x_discrete(breaks=NULL)+
        theme_minimal(base_size=12)+
        theme(panel.grid.minor=element_blank(),legend.position="none",axis.text.x=element_blank(),axis.title.y=element_text(size=10, face="bold.italic"),axis.text.y=element_text(size=8), strip.text.x=element_text(face="bold.italic"))+
        guides(alpha = FALSE)+
        facet_wrap(~ group2, scale="free_y", nrow=1)
    }
    Data_BasePairs1<-read.table(file.path(split.vars[nn], paste0(Name_Of_Runs_To_Compare[nn],"_BasePairsProduced.txt")), header=T, sep="\t")
    if (length(Data_BasePairs1[,1]) != length(Group2)) {  
      x<-c(Data_BasePairs1$x,seq(max(Data_BasePairs1$x)+.5, max(Table_List[[Major_Index]]$x),0.5))
      y<-c(Data_BasePairs1$y, rep(0, length(seq(max(Data_BasePairs1$x)+.5, max(Table_List[[Major_Index]]$x),0.5))))
      group<-rep("Base Pairs", length(y))
      value<-rep(Name_Of_Runs_To_Compare[nn], length(y))
      group2<-factor(as.character(New_Group_2), levels=c("0-10 hours","10-20 hours","20-30 hours","30-40 hours","40-50 hours"))
      Data_BasePairs1<-data.frame(x,y,group,value,group2)
    }
    else {
      Data_BasePairs1$group<-"Base Pairs"
      Data_BasePairs1$value<-Name_Of_Runs_To_Compare[nn]
      Data_BasePairs1$group2<-factor(as.character(New_Group_2), levels=c("0-10 hours","10-20 hours","20-30 hours","30-40 hours","40-50 hours"))
    }
    List_Data_BasePairs[[nn]]<-Data_BasePairs1
    if (length(List_Data_BasePairs) == length(split.vars)) {
      BasePairs_To_Plot<-do.call(rbind, List_Data_BasePairs)
      Violins_BasePairs<-ggplot(BasePairs_To_Plot, aes(x=group,y=y, fill=value)) + 
        geom_violin(draw_quantiles = c(0.25, 0.5, 0.75))+
        labs(x="", y = "Base Pairs")+ 
        scale_fill_brewer(palette="Set3") + 
        scale_x_discrete(breaks=NULL)+
        theme_minimal(base_size=12)+
        theme(panel.grid.minor=element_blank(),legend.position="none",axis.text.x=element_blank(),axis.title.y=element_text(size=10, face="bold.italic"),axis.text.y=element_text(size=8),strip.text=element_blank())+
        guides(alpha = FALSE)+
        facet_wrap(~ group2, scale="free_y", nrow=1)
    }
    Data_Mean_Length1<-read.table(file.path(split.vars[nn], paste0(Name_Of_Runs_To_Compare[nn],"_MeanLength.txt")), header=T, sep="\t")
    if (length(Data_Mean_Length1[,1]) != length(Group2)) {
      x<-c(Data_Mean_Length1$x,seq(max(Data_Mean_Length1$x)+.5, max(Table_List[[Major_Index]]$x),0.5))
      y<-c(Data_Mean_Length1$y, rep(0, length(seq(max(Data_Mean_Length1$x)+.5, max(Table_List[[Major_Index]]$x),0.5))))
      group<-rep("Length", length(y))
      value<-rep(Name_Of_Runs_To_Compare[nn], length(y))
      group2<-factor(as.character(New_Group_2), levels=c("0-10 hours","10-20 hours","20-30 hours","30-40 hours","40-50 hours"))
      Data_Mean_Length1<-data.frame(x,y,group,value,group2)
    }
    else {
      Data_Mean_Length1$group<-"Length"
      Data_Mean_Length1$value<-Name_Of_Runs_To_Compare[nn]
      Data_Mean_Length1$group2<-factor(as.character(New_Group_2), levels=c("0-10 hours","10-20 hours","20-30 hours","30-40 hours","40-50 hours"))
    }
    List_Data_Length[[nn]]<-Data_Mean_Length1
    if (length(List_Data_Length) == length(split.vars)) {
      Length_To_Plot<-do.call(rbind, List_Data_Length)
      Violins_Length<-ggplot(Length_To_Plot, aes(x=group,y=y, fill=value)) + 
        geom_violin(draw_quantiles = c(0.25, 0.5, 0.75))+
        labs(x="", y = "Length")+ 
        scale_fill_brewer(palette="Set3") + 
        scale_x_discrete(breaks=NULL)+
        theme_minimal(base_size=12)+
        theme(panel.grid.minor=element_blank(),legend.position="none",axis.text.x=element_blank(),axis.title.y=element_text(size=10, face="bold.italic"),axis.text.y=element_text(size=8), strip.text=element_blank())+
        guides(alpha = FALSE)+
        facet_wrap(~ group2, scale="free_y", nrow=1)
    }
    Data_Mean_Quality1<-read.table(file.path(split.vars[nn], paste0(Name_Of_Runs_To_Compare[nn],"_MeanQuality.txt")), header=T, sep="\t")
    if (length(Data_Mean_Quality1[,1]) != length(Group2)) {
      x<-c(Data_Mean_Quality1$x,seq(max(Data_Mean_Quality1$x)+.5, max(Table_List[[Major_Index]]$x),0.5))
      y<-c(Data_Mean_Quality1$y, rep(0, length(seq(max(Data_Mean_Quality1$x)+.5, max(Table_List[[Major_Index]]$x),0.5))))
      group<-rep("Quality", length(y))
      value<-rep(Name_Of_Runs_To_Compare[nn], length(y))
      group2<-factor(as.character(New_Group_2), levels=c("0-10 hours","10-20 hours","20-30 hours","30-40 hours","40-50 hours"))
      Data_Mean_Quality1<-data.frame(x,y,group,value,group2)
    }
    else {
      Data_Mean_Quality1$group<-"Quality"
      Data_Mean_Quality1$value<-Name_Of_Runs_To_Compare[nn]
      Data_Mean_Quality1$group2<-factor(as.character(New_Group_2), levels=c("0-10 hours","10-20 hours","20-30 hours","30-40 hours","40-50 hours"))
    }
    List_Data_Quality[[nn]]<-Data_Mean_Quality1
    if (length(List_Data_Quality) == length(split.vars)) {
      Quality_To_Plot<-do.call(rbind, List_Data_Quality)
      Violins_Quality<-ggplot(Quality_To_Plot, aes(x=group,y=y, fill=value)) + 
        geom_violin(draw_quantiles = c(0.25, 0.5, 0.75))+
        labs(x="", y = "Quality")+ 
        scale_fill_brewer(palette="Set3") + 
        scale_x_discrete(breaks=NULL)+
        theme_minimal(base_size=12)+
        theme(panel.grid.minor=element_blank(),legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=8),axis.text.x=element_blank(),axis.title.y=element_text(size=10, face="bold.italic"),axis.text.y=element_text(size=8), strip.text=element_blank())+
        guides(alpha = FALSE,fill = guide_legend(nrow = 1,label.position = "bottom"))+
        facet_wrap(~ group2, scale="free_y", nrow=1)
    }
  }
  mylegend<-g_legend(Violins_Quality)
  
  
  All_Violins_Together<-grid.arrange(Violins_Reads + theme(legend.position="none"), Violins_BasePairs + theme(legend.position="none"), Violins_Length + theme(legend.position="none"), Violins_Quality + theme(legend.position="none"), mylegend, nrow=5,heights=c(2.3,2.3,2.3,2.3,.8))


  
  ggsave("Comparison_Violins.pdf", device="pdf",All_Violins_Together, height=10, width=15)

  message("Done!")
  
  ######HISTOGRAM COMPARISON
  
  List_Reads_Length<-list()
  List_Reads_Quality<-list()
  List_Reads_GC<-list()
  
  if (GCC == TRUE) {

  	message("Creating comparison histograms with GC content...")
    
    
    for (nnn in 1:length(split.vars)) {
      Info_Table<-read.table(file.path(split.vars[nnn], paste0(Name_Of_Runs_To_Compare[nnn],"_Information_Table.txt")), header=T, sep="\t")
      Read_Length<-as.numeric(log10(Info_Table[,5]))
      value<-rep(Name_Of_Runs_To_Compare[nnn], length(Read_Length))
      group<-rep("Reads Length",length(Read_Length))
      Read_Length_DF<-data.frame(x=Read_Length, value, group)
      List_Reads_Length[[nnn]]<-Read_Length_DF
      if (length(List_Reads_Length) == length(split.vars)) {
        Table_Reads<-do.call(rbind,List_Reads_Length)
        Reads_Plot<-ggplot(Table_Reads, aes(x=x, fill=value)) + theme_bw() +geom_histogram(col="black")+scale_fill_brewer(palette="Set3") + labs(x="Length (log10)",y="Count")+theme(legend.position="none",axis.title.y=element_text(face="bold.italic"),axis.title.x=element_text(face="bold.italic"),strip.text.x = element_blank())+facet_wrap(~ value, scale="free_y",nrow=1)
      }
      Read_Quality<-as.numeric(Info_Table[,6])
      value<-rep(Name_Of_Runs_To_Compare[nnn], length(Read_Quality))
      group<-rep("Reads Quality",length(Read_Quality))
      Read_Quality_DF<-data.frame(x=Read_Quality, value, group)
      List_Reads_Quality[[nnn]]<-Read_Quality_DF
      if (length(List_Reads_Quality) == length(split.vars)) {
        Table_Quality<-do.call(rbind,List_Reads_Quality)
        Quality_Plot<-ggplot(Table_Quality, aes(x=x, fill=value)) + theme_bw()+ xlim(0,20)+geom_histogram(col="black")+scale_fill_brewer(palette="Set3") + labs(x="Quality",y="Count")+theme(legend.position="none",axis.title.y=element_text(face="bold.italic"),axis.title.x=element_text(face="bold.italic"),strip.text.x = element_blank())+facet_wrap(~value, scale="free_y",nrow=1)
      }
      Read_GC_Content<-as.numeric(Info_Table[,7])
      value<-rep(Name_Of_Runs_To_Compare[nnn], length(Read_GC_Content))
      group<-rep("Reads GC Content",length(Read_GC_Content))
      Read_GC_DF<-data.frame(x=Read_GC_Content, value, group)
      List_Reads_GC[[nnn]]<-Read_GC_DF
      if(length(List_Reads_GC) == length(split.vars)) {
        GC_Table<-do.call(rbind,c(List_Reads_GC))
        GC_Plot<-ggplot(GC_Table, aes(x=x, fill=value)) + theme_bw()+ xlim(0,1)+geom_histogram(col="black")+scale_fill_brewer(palette="Set3") + labs(x="GC Content",y="Count")+theme(legend.position="bottom",legend.title=element_blank(),legend.text=element_text(size=8),axis.title.y=element_text(face="bold.italic"),axis.title.x=element_text(face="bold.italic"),strip.text.x = element_blank())+facet_wrap(~value, scale="free_y",nrow=1)+guides(fill = guide_legend(nrow = 1,label.position = "bottom"))
      }
    }
    
    mylegend2<-g_legend(GC_Plot)
    
    Reads_Length_Quality_GC<-grid.arrange(Reads_Plot,Quality_Plot,GC_Plot+theme(legend.position="none"),mylegend2, nrow=4,heights=c(3.2,3.2,3.2,0.4))
    
    ggsave("Comparison_Histograms.pdf",device="pdf",Reads_Length_Quality_GC,height=10, width=15)

    message("Done!")
  }
  
  if (GCC == FALSE) {

  	message("Creating comparison histograms without GC content...")
    
    for (nnn in 1:length(split.vars)) {
      Info_Table<-read.table(file.path(split.vars[nnn], paste0(Name_Of_Runs_To_Compare[nnn],"_Information_Table.txt")), header=T, sep="\t")
      Read_Length<-as.numeric(log10(Info_Table[,5]))
      value<-rep(Name_Of_Runs_To_Compare[nnn], length(Read_Length))
      group<-rep("Reads Length",length(Read_Length))
      Read_Length_DF<-data.frame(x=Read_Length, value, group)
      List_Reads_Length[[nnn]]<-Read_Length_DF
      if (length(List_Reads_Length) == length(split.vars)) {
        Table_Reads<-do.call(rbind,List_Reads_Length)
        Reads_Plot<-ggplot(Table_Reads, aes(x=x, fill=value)) + theme_bw() +geom_histogram(col="black")+scale_fill_brewer(palette="Set3") + labs(x="Length (log10)",y="Count")+theme(legend.position="none",axis.title.y=element_text(face="bold.italic"),axis.title.x=element_text(face="bold.italic"),strip.text.x = element_blank())+facet_wrap(~ value, scale="free_y",nrow=1)
      }
      Read_Quality<-as.numeric(Info_Table[,6])
      value<-rep(Name_Of_Runs_To_Compare[nnn], length(Read_Quality))
      group<-rep("Reads Quality",length(Read_Quality))
      Read_Quality_DF<-data.frame(x=Read_Quality, value, group)
      List_Reads_Quality[[nnn]]<-Read_Quality_DF
      if (length(List_Reads_Quality) == length(split.vars)) {
        Table_Quality<-do.call(rbind,List_Reads_Quality)
        Quality_Plot<-ggplot(Table_Quality, aes(x=x, fill=value)) + theme_bw()+ xlim(0,20)+geom_histogram(col="black")+scale_fill_brewer(palette="Set3") + labs(x="Quality",y="Count")+theme(legend.text=element_text(size=8),legend.position="bottom",legend.title=element_blank(),axis.title.y=element_text(face="bold.italic"),axis.title.x=element_text(face="bold.italic"),strip.text.x = element_blank())+facet_wrap(~value, scale="free_y",nrow=1)+guides(fill = guide_legend(nrow = 1,label.position = "bottom"))
      }
    }
    
    mylegend2<-g_legend(Quality_Plot)
    
    Reads_Length_Quality<-grid.arrange(Reads_Plot,Quality_Plot+theme(legend.position="none"),mylegend2, nrow=3,heights=c(3.2,3.2,0.6))

    ggsave("Comparison_Histograms.pdf",device="pdf",Reads_Length_Quality,height=10, width=15)

    message("Done!")
  }
}

